var base_url = '/bizflowwebmaker/whrsc_branchAUT/';

function InitForm()
{
	hyf.util.disableComponent('bodySection');

	hyf.util.enableComponent('GLOBAL_RECRUITMENT');
	hyf.util.enableComponent('HR_SPECIALIST_2');
	
	var hrUGPath = '/WHRSC/Role Specific/HR Specialist/';
	var branchName = $('#h_branch').val();
	hrUGPath = 	hrUGPath + branchName;
	$('#h_branchUG').val(hrUGPath);

	$.ajax({
		url: base_url + 'getBranchHS.do?branchhs=' + hrUGPath,
		dataType: 'xml',
		cache: false,
		success: function (xmlResponse) {
			$('#HR_SPECIALIST_2').empty();
			$('#HR_SPECIALIST_2').append('<option value= >Select One</option>');
			var data = $('record', xmlResponse ).map(function() {
				 $('#HR_SPECIALIST_2').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
			}).get();
			
		}
	});	

	$('#HR_SPECIALIST_2').on("change", function(){
		var txt = $('#HR_SPECIALIST_2 option:selected').text();
		$('#h_hrspecialistName').val(txt);
		var val = $('#HR_SPECIALIST_2 option:selected').val();
		$('#h_hrspecialistId').val('[U]'+val);
	});

	$('#GLOBAL_RECRUITMENT').on("change", function(){
		var selVal = $(this).children("option:selected").val();
		
		if (selVal == 'Yes') {
			$('#h_branch').val("SSB");
			$.ajax({
				url: base_url + 'getBranchHS.do?branchhs=' + "/WHRSC/Role Specific/HR Specialist/SSB",
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#HR_SPECIALIST_2').empty();
					$('#HR_SPECIALIST_2').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#HR_SPECIALIST_2').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();
					
				}
			});	
			
		}else {
			var orgBranch = $('#h_originalBranch').val();
			$('#h_branch').val(orgBranch);
			$.ajax({
				url: base_url + 'getBranchHS.do?branchhs=' + "/WHRSC/Role Specific/HR Specialist/" + orgBranch,
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#HR_SPECIALIST_2').empty();
					$('#HR_SPECIALIST_2').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#HR_SPECIALIST_2').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();
					
				}
			});	
		}
	});
	

}

function getHr() {
	var txt = $('#HR_SPECIALIST_2 option:selected').text();
	$('#h_hrspecialistName').val(txt);
	var val = $('#HR_SPECIALIST_2 option:selected').val();
	$('#h_hrspecialistId').val('[U]'+val);
}

function submitButton()
{
	if($('#h_actionType').val()=='Cancel') {
		$('#h_status').val('CANCELLED');
		var now = new Date();
		var sysDate = utility.getDateString({isUTC: false, dateFormat: 'yyyy/mm/dd hh:MM:ss'}, now);
		$('#h_statusDate').val(sysDate);
		$('#h_statusUserID').val($('#h_currentUserID').val());
	}
	else {
		hyf.util.enableComponent('bodySection');
		$('#h_rypCode').val('Yellow');
		$('#h_ryb_status').val('Active in HR');
		$('#h_ryb_description').val('Waiting for missing documents');	
		
		$('#h_status').val('ACTIVE');
		var now = new Date();
		var sysDate = utility.getDateString({isUTC: false, dateFormat: 'yyyy/mm/dd hh:MM:ss'}, now);
		$('#h_statusDate').val(sysDate);
		$('#h_statusUserID').val($('#h_currentUserID').val());

		var dateReceievedString = $('#DATE_RECEIVED').val();
		if (dateReceievedString != null && dateReceievedString.length > 0) {
			var dateReceieved = new Date(dateReceievedString);  
			dateReceieved = utility.getDateString({isUTC: false, dateFormat: 'yyyy-mm-ddThh:MM:ss'}, dateReceieved);
			$('#h_date_sf52_received').val(dateReceieved);
		}
	}
}



function removeSizeLabel(element) {
		var target = null;
		var nodeName = $(element).get(0).tagName;
		if (nodeName == 'input') {
			if ($(element).hasClass('dijitInputInner')) {
				target = $(element).parent().parent().parent();
			} else {
				target = $(element).parent().parent();
			}
		} else if (nodeName == 'textarea') {
			target = $(element).parent();
		}

		if (target != null && target.length > 0) {
			$(target).find('p.sizeLabel').remove();
		}
	}
	
function setAlwaysDisabled(elementID) {
		var element = $('#' + elementID);
		var selectorKey = '#' + elementID;
		$(element).attr('disabled','disabled');
		$(element).attr('alwaysDisabled','true');

		removeSizeLabel(element);
	}