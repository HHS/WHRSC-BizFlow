var getSecurity = function(){

    $('#G_DOB_calendar_anchor').attr('tabindex', 260);

    $('#G_LAST_NAME').val(opener.document.getElementById("A_NAME_INPUT").value).attr({ readonly:'readonly', style:'background-color:#efefef' });
    $('#G_FIRST_NAME').val(opener.document.getElementById("A_NAME_INPUT_F").value).attr({ readonly:'readonly', style:'background-color:#efefef' });
    $('#h_requisitionNumber').val(opener.document.getElementById("h_requisitionNumber").value);
    $('#h_transaction_id').val(opener.document.getElementById("h_transactionNumber").value);

    $('#h_idType_selected').val('SSN');
    $("#ID_TYPE").change(function() {
      var selectedID = $(this).find(':selected').val();
      $('#h_idType_selected').val(selectedID);
    });

    $('#VISA_GROUP').hide();
    $('#ALIEN_REG_GROUP').hide();
    $('#FOREIGN_ID_GROUP').hide();

    $('#ID_TYPE').on("change", function(){
      var idTypeSelected =  $('#ID_TYPE option:selected').val();
      switch (idTypeSelected){
        case 'SSN':
          $('#SSN_GROUP').show();
          $('#VISA_GROUP,#ALIEN_REG_GROUP,#FOREIGN_ID_GROUP').hide();
          $('#G_VISA,#G_ALIEN_NUM,#G_FOREIGN_ID,#G_FOREIGN_COUNTRY').val('');
          break;
        case 'VISA Number':
          $('#VISA_GROUP').show();
          $('#SSN_GROUP,#ALIEN_REG_GROUP,#FOREIGN_ID_GROUP').hide();
          $('#G_SSN,#G_ALIEN_NUM,#G_FOREIGN_ID,#G_FOREIGN_COUNTRY').val('');
          break;
        case 'Alien Registration Number':
          $('#ALIEN_REG_GROUP').show();
          $('#VISA_GROUP,#SSN_GROUP,#FOREIGN_ID_GROUP').hide();
          $('#G_VISA,#G_SSN,#G_FOREIGN_ID,#G_FOREIGN_COUNTRY').val('');
          break;
        case 'Foreign ID':
          $('#FOREIGN_ID_GROUP').show();
          $('#VISA_GROUP,#ALIEN_REG_GROUP,#SSN_GROUP').hide();
          $('#G_VISA,#G_ALIEN_NUM,#G_SSN').val('');
          break;
      }
    });

    $('<div id="overlay"/>').css({
         'background-color': '#333',
         'opacity': '0.8',
         'position': 'absolute',
         'left': '0px',
         'top': '0px',
         'z-index': '100',
         'height': '100%',
         'width': '100%',
         'overflow': 'hidden',
         'background-position': 'center',
         'background-repeat': 'no-repeat'
      }).hide().appendTo('body');

    emptyAffiliation();

    // DISABLE AFFILIATION QUERY IN WM GET_SECURITY AND DELETE TEXT IN --Display Text if no option is selected--
    // CREATE THE GetAffiliation.do TO QUERY AFFILIATION INSTEAD (AJAX BELOW)

    $('#G_OPDIV').on("change", function(){
      var selectedOpDiv = $(this).find(':selected').val();
      if (selectedOpDiv == '') {
        emptyAffiliation();
      } else {
        appendAffiliations(selectedOpDiv);
      }
    });

}
var emptyAffiliation = function(){
  $('#G_AFFILIATION').empty().append('<option value= >Select One OPDIV First</option>').attr({readonly:'readonly', style:'background-color:#efefef'});
}

var appendAffiliations = function(selectedOpDiv){
  $.ajax({
        url: '/bizflowwebmaker/whrsc_AUT/GetAffiliation.do?OpDiv=' + selectedOpDiv,
        dataType: 'xml',
        cache: false,
        success: function (xmlResponse) {

          //CHECK HOW IT WAS DONE   ->    MANAGELIST.JS:71,101
          $('#G_AFFILIATION').attr({style:'background-color:#fff'}).removeAttr('readonly').empty().append('<option value= >Select One</option>');
  				var data = $('record', xmlResponse ).map(function() {
  					 $('#G_AFFILIATION').append('<option value=\"' + $( 'AFFILIATION_CODE', this ).text() + '\">' + $( 'AFFILIATION_CODE', this ).text() + '</option>');
  				}).get();
        }
    });
}

var mandatoryValues = function(){
  var isFull = false;
  if ( ( ($('#G_FOREIGN_ID').val() != '' &&  $('#G_FOREIGN_COUNTRY').val() != '')
          || $('#G_SSN').val() != ''
          || $('#G_VISA').val() != ''
          || $('#G_ALIEN_NUM').val() != ''
        )
        && $('#G_LAST_NAME').val() != ''
        && $('#G_FIRST_NAME').val() != ''
        && $('#G_DOB').val() != ''
        && $('#G_OPDIV').val() != ''
        && $('#G_AFFILIATION').val() != ''
      ) {
    isFull = true;
  } else {
    alert('Please complete Mandatory Fields');
  }
  return isFull;
};

var resp_hhsId = '';
var resp_resultCode = '';
var resp_resultMessage = '';
var resp_failureDetailMessage = '';

var callInductionService = function(){
  var xmlRequest = "<InductionRequest><FirstName>"+
            $('#G_FIRST_NAME').val()+"</FirstName><LastName>"+
            $('#G_LAST_NAME').val()+"</LastName><SSN>"+
            $('#G_SSN').val()+"</SSN><ARN>"+
            $('#G_ALIEN_NUM').val()+"</ARN><VisaNumber>"+
            $('#G_VISA').val()+"</VisaNumber><ForeignIdNumber>"+
            $('#G_FOREIGN_ID').val()+"</ForeignIdNumber><ForeignIdIssuingCountry>"+
            $('#G_FOREIGN_COUNTRY').find(':selected').val()+"</ForeignIdIssuingCountry><DOB>"+
            $('#G_DOB').val()+"</DOB><OPDIV>"+
            $('#G_OPDIV').find(':selected').val()+"</OPDIV><AffiliationCode>"+
            $('#G_AFFILIATION').find(':selected').val()+"</AffiliationCode></InductionRequest>";
  $.ajax({
        type: 'POST',
        url: '/scmsswsc/induction/inductPerson',
        dataType: 'application/x-www-form-urlencoded',
        data: xmlRequest,
        contentType: "application/xml",
        cache: false,
        async: false,
        success: function (xmlResponse) {
          var xmlString = xmlResponse.responseText;
          resp_hhsId = $(xmlString).find('HHSID').text();
          resp_resultCode = $(xmlString).find('ResultCode').text();
          resp_resultMessage = $(xmlString).find('ResultMessage').text();
          resp_failureDetailMessage = $(xmlString).find('FailureDetailMessage').text();
        },
        error: function(xmlErrorResponse) {
          var xmlString = xmlErrorResponse.responseText;
    		  resp_hhsId = $(xmlString).find('HHSID').text();
    		  resp_resultCode = $(xmlString).find('ResultCode').text();
    		  resp_resultMessage = $(xmlString).find('ResultMessage').text();
    		  resp_failureDetailMessage = $(xmlString).find('FailureDetailMessage').text();
        }
    });
    if (resp_hhsId != '') {
      opener.document.getElementById("h_wasSubmitted").value = 'true';
      opener.document.getElementById("h_a_hhsid").value = resp_hhsId;
    }
    $('#h_hhsId').val(resp_hhsId);
    $('#h_resultCode').val(resp_resultCode);
    $('#h_resultMessage').val(resp_resultMessage);
    $('#h_failureDetailMessage').val(resp_failureDetailMessage);
};

var greyOut = function(){
  $('#overlay').show();
  $('#ID_TYPE,#G_FOREIGN_ID,#G_FOREIGN_COUNTRY,#G_VISA,#G_ALIEN_NUM,#G_SSN,#G_DOB,#G_OPDIV,#G_AFFILIATION').attr({
    readonly:'readonly', style:'background-color:#efefef'
  });
};

var closeWindow = function(){
  if (resp_resultCode == 'Success') {
    alert('Security Information Request has been sent.\n\nResponse:\n' + resp_resultCode + '\n' + resp_resultMessage);

    window.close();
  } else {
    if (resp_resultMessage != '')
      alert('Problem sending Security Information Request.\n\nResponse:\n' + resp_resultCode + '\n' + resp_resultMessage + '\n' + resp_failureDetailMessage);
    else
      alert('Error sending Security Information Request.\n\nResponse:\n' + resp_resultCode + '\n' + resp_failureDetailMessage);

    $('#overlay').hide();
    $('#ID_TYPE,#G_FOREIGN_ID,#G_FOREIGN_COUNTRY,#G_VISA,#G_ALIEN_NUM,#G_SSN,#G_DOB,#G_OPDIV,#G_AFFILIATION').attr({style:'background-color:#fff'});
    $('#ID_TYPE,#G_FOREIGN_ID,#G_FOREIGN_COUNTRY,#G_VISA,#G_ALIEN_NUM,#G_SSN,#G_DOB,#G_OPDIV,#G_AFFILIATION').removeAttr('readonly');
  }
};
