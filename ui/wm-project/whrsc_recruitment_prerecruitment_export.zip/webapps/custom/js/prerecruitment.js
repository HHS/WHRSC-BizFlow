var base_url = '/bizflowwebmaker/whrsc_AUT/';
var _USAS_DATA = '';

var preRecruit = function(){

	var  parentProcess = $('#pv_parentProcessID').val();
	

	var actName = WHRSCMain.activityOption.getActivityName();
	if(actName!="DEU Reviews/ Approves/Creates Vacancy/Cert") {
		WHRSCMain.setAlwaysReadonly('DATE_10PT_FILE_CHECKED');
        $('#DATE_10PT_FILE_CHECKED').css('background-color', '#efefef');
		$('#DATE_10PT_FILE_CHECKED_calendar_anchor').addClass('hidden');
        
        WHRSCMain.setAlwaysReadonly('REC_PCKG_NOTES');
        $('#REC_PCKG_NOTES').css('background-color', '#efefef');

		WHRSCMain.setAlwaysReadonly('DATE_REC_PCKG_SENT_DEU');
        $('#DATE_REC_PCKG_SENT_DEU').css('background-color', '#efefef');
		$('#DATE_REC_PCKG_SENT_DEU').css('width', 400);
		$('#DATE_REC_PCKG_SENT_DEU_calendar_anchor').addClass('hidden');
		WHRSCMain.setAlwaysReadonly('DATE_REC_PCKG_SENT_APPROVED');
        $('#DATE_REC_PCKG_SENT_APPROVED').css('background-color', '#efefef');
		$('#DATE_REC_PCKG_SENT_APPROVED').css('width', 400);
		$('#DATE_REC_PCKG_SENT_APPROVED_calendar_anchor').addClass('hidden');
	}
    
    //508 setup
    $('#LEGISLATIVE_INIT_SUPPORTED_label').attr('title', 'Asterisk denotes a required field');
    $('#IS_READVERTISEMENT_label').attr('title', 'Asterisk denotes a required field');
    $('#HR_CARDS_PD_USED_label').attr('title', 'Asterisk denotes a required field');
    $('#SUBMITTED_PCKG_QUALITY_label').attr('title', 'Asterisk denotes a required field');
    $('#SUBMITTED_PCKG_QUALITY_CMNTS_label').attr('title', 'Asterisk denotes a required field');
    $('#IS_TRANSITIONAL_RECRUIT_label').attr('title', 'Asterisk denotes a required field');
    $('#OTHER_RECRUIT_CONSIDERATIONS_label').attr('title', 'Asterisk denotes a required field');
    $('#PAID_AD_label').attr('title', 'Asterisk denotes a required field');
    $('#IS_RELOCATION_EXPENSES_PAID_label').attr('title', 'Asterisk denotes a required field');
    $('#DATE_JOB_OPENING_APPROVED_label').attr('title', 'mm/dd/yyyy');
    $('#DATE_PRERECRUIT_MEETING_label').attr('title', 'mm/dd/yyyy');
    $('#DATE_PRERECRUIT_SHEET_SIGNED_label').attr('title', 'mm/dd/yyyy');
    $('#PAID_AD_APPROVED_DATE_label').attr('title', 'mm/dd/yyyy');
    $('#DATE_PRT_PLCMT_PGM_CHECKED_label').attr('title', 'mm/dd/yyyy');
    
    /*for (var index = 1; index <= 100; index++) {
        $('#record_repeat' + index + 'PAYPLAN').html(addComma2($('#record_repeat' + index + 'PAYPLAN').html()));
    }*/
    
    //calendar icon tabindex
    $('#DATE_JOB_OPENING_APPROVED_calendar_anchor').attr('tabindex', 71);
    $('#DATE_PRERECRUIT_MEETING_calendar_anchor').attr('tabindex', 81);
    $('#DATE_PRERECRUIT_SHEET_SIGNED_calendar_anchor').attr('tabindex', 91);
    $('#DATE_NEED_VALIDATED_calendar_anchor').attr('tabindex', 111);
    $('#PAID_AD_APPROVED_DATE_calendar_anchor').attr('tabindex', 931);
    $('#DATE_PRT_PLCMT_PGM_CHECKED_calendar_anchor').attr('tabindex', 943);
    $('#DATE_10PT_FILE_CHECKED_calendar_anchor').attr('tabindex', 945);
    $('#SUBMITTED_PCKG_QUALITY_label_hint_container').attr('tabindex', 991);
    
    
    
    
    $('#SUPERVISOR_EMAIL_container').addClass('hidden');
	$('#SUPERVISOR_EMAIL').attr('_required', 'false');
    
    $('#SUPERVISOR_FIRST_NAME_container').addClass('hidden');
	$('#SUPERVISOR_FIRST_NAME').attr('_required', 'false');
    
    $('#OFFICIAL_EMAIL_container').addClass('hidden');
	$('#OFFICIAL_EMAIL').attr('_required', 'false');
    
    //$('#admin_code_section_8').addClass('hidden');
	
    
    $('#OFFICIAL_FIRST_NAME_container').addClass('hidden');
	$('#OFFICIAL_FIRST_NAME').attr('_required', 'false');
    
    
    //$('#TransactionInfo_AC_16').attr('_type', 'text');
    $('#PRERECRUIT_COMMENTS').attr('_type', 'string');
    $('#SUBMITTED_PCKG_QUALITY_CMNTS').attr('_type', 'string');

	if(parentProcess=='' || parentProcess==undefined)
	{
		if($('#h_reqAdminEditable').val()=='no') {
			WHRSCMain.setAlwaysReadonly('JOB_OPENING_ID');
			$('#JOB_OPENING_ID').css('background-color', '#efefef');
		}
		else {
			var requestNumber = $('#pv_requistionNumber').val();
			var usasResult = $('#husasResult').val();
			if (requestNumber != '' && usasResult=="true")  {
				var preComment= '';
				var canNumber= '';
				var dateJobReqApp= '';

				$.ajax({
					url: base_url + 'searchReqNumber.do?searchRequestNumber=' + requestNumber,
					dataType: 'xml',
					cache: false,
					async: false,
					success: function (xmlResponse) {
						var data = $('record', xmlResponse ).map(function() {
							preComment = $( 'CAPHR_COMMENTS', this ).text();
							canNumber = $( 'CAN_NUMBER', this ).text();
							dateJobReqApp = $( 'DATE_JOB_REQ_APPROVED', this ).text();
						
						}).get();
					}
				});	
				var dateJobReqAppLabel = "";
				var dateJobReqAppStr = dateJobReqApp;
				if (dateJobReqAppStr != null && dateJobReqAppStr.length > 0) {
					var dateJobReqApprov = new Date(dateJobReqAppStr);
					dateJobReqAppLabel = utility.getDateString({isUTC: false, dateFormat: 'mm/dd/yyyy'}, dateJobReqApprov);
				}	
				$('#PRERECRUIT_COMMENTS').val(preComment);
				$('#CAN_NO').val(canNumber);
				$('#DATE_JOB_OPENING_APPROVED').val(dateJobReqAppLabel);
			}
		}
		//$('#pv_positionTitle').val($('#h_positionTitle').val());
		//$('#pv_payPlan').val($('#h_payPlan').val());
		//$('#pv_series').val($('#h_series').val());
		//$('#pv_grade').val($('#h_grade').val());
	}
	else {
		WHRSCMain.setAlwaysReadonly('JOB_OPENING_ID');
        $('#JOB_OPENING_ID').css('background-color', '#efefef');

	}

    WHRSCMain.setAlwaysReadonly('DATE_NEED_VALIDATED');
    $('#DATE_NEED_VALIDATED').css('background-color', '#efefef');
    //WHRSCMain.setAlwaysDisabled('DATE_NEED_VALIDATED_calendar_anchor');
    $('#DATE_NEED_VALIDATED_calendar_anchor').addClass('hidden');

	WHRSCMain.setAlwaysReadonly('NUM_POSITIONS_TO_BE_ADV');
    $('#NUM_POSITIONS_TO_BE_ADV').css('background-color', '#efefef');

	WHRSCMain.setAlwaysReadonly('CLEARANCE_LEVEL_REQUIRED');
    $('#CLEARANCE_LEVEL_REQUIRED').css('background-color', '#efefef');
    
    if ($('#HR_CARDS_PD_USED').val() != 'Yes'){
            WHRSCMain.setAlwaysReadonly('HR_CARDS_PD_KEY_NUMBER');    
            $('#HR_CARDS_PD_KEY_NUMBER').css('background-color', '#efefef');
        }
    $('#HR_CARDS_PD_USED').on('change',function(e) {
        
        var rdrck = $(this).children("option:selected").val();
               
        if (rdrck == 'Yes') {
            $('#HR_CARDS_PD_KEY_NUMBER').removeAttr("readonly");
        	$('#HR_CARDS_PD_KEY_NUMBER').css('background-color', '#ffffff');
        }else{
            WHRSCMain.setAlwaysReadonly('HR_CARDS_PD_KEY_NUMBER');    
            $('#HR_CARDS_PD_KEY_NUMBER').css('background-color', '#efefef');
            $('#HR_CARDS_PD_KEY_NUMBER').val('');
        }
    });
    
    if($('#SUBMITTED_PCKG_QUALITY').val() == 'Green'){
        $('#SUBMITTED_PCKG_QUALITY_CMNTS').attr('_required', 'false');
        $('#SUBMITTED_PCKG_QUALITY_CMNTS_marker').addClass('hidden');
        $('#SUBMITTED_PCKG_QUALITY_CMNTS_label').attr('title', '');
    }
    
     $('#SUBMITTED_PCKG_QUALITY').on('change', function(){
		var selVal = $(this).children('option:selected').val();
        
         if (selVal == 'Green'){
             $('#SUBMITTED_PCKG_QUALITY_CMNTS').attr('_required', 'false');
             $('#SUBMITTED_PCKG_QUALITY_CMNTS_marker').addClass('hidden');
             $('#SUBMITTED_PCKG_QUALITY_CMNTS_label').attr('title', '');
         }else{
             $('#SUBMITTED_PCKG_QUALITY_CMNTS').attr('_required', 'true');
             $('#SUBMITTED_PCKG_QUALITY_CMNTS_marker').removeClass('hidden');
             $('#SUBMITTED_PCKG_QUALITY_CMNTS_label').attr('title', 'Asterisk denotes a required field');
         }
     });

    //setReqNumAutoComplete();
    setPrAutoComplete();
    setOfAutoComplete();
    
	
	var sharedAnns = $('#h_sharedAnns').val();	
	if (sharedAnns != '') {
		var split = sharedAnns.split(',');
		var splitCnt = split.length;
		for (var i=0;i <splitCnt;i++) {
			var liVal = "<li id=\"" + split[i] + "\" ><b>";
					liVal += removefuncOf.getAutoCompRemoveIconElement(split[i] ,split[i] , 875+i);
					liVal += split[i]  + '</b></li>';
					if(i==0) {
						$('#SHARED_DP1').append(liVal).removeClass('hidden');
					}
					else if(i==1) {
						$('#SHARED_DP2').append(liVal).removeClass('hidden');
					}
					else if(i==2) {
						$('#SHARED_DP3').append(liVal).removeClass('hidden');
					}
					else if(i==3) {
						$('#SHARED_DP4').append(liVal).removeClass('hidden');
					}
					else if(i==4) {
						$('#SHARED_DP5').append(liVal).removeClass('hidden');
					}
					else if(i==5) {
						$('#SHARED_DP6').append(liVal).removeClass('hidden');
					}
					else if(i==6) {
						$('#SHARED_DP7').append(liVal).removeClass('hidden');
					}
					else if(i==7) {
						$('#SHARED_DP8').append(liVal).removeClass('hidden');
					}
					else if(i==8) {
						$('#SHARED_DP9').append(liVal).removeClass('hidden');
					}
					else if(i==9) {
						$('#SHARED_DP10').append(liVal).removeClass('hidden');
					}
					//$('#SHARED_DP' + i+1).append(liVal).removeClass('hidden');
					//$('#SHARED_DP1').append(liVal).removeClass('hidden');					
		}
	}

    if ($('#s_lastname').val() != '') {
        
        	var li_last_name = "<li id=\"" + $('#s_lastname').val() + "\" ><b>";
			li_last_name += removefunc.getAutoCompRemoveIconElement($('#s_lastname').val(), $('#s_lastname').val(), '31');
            li_last_name += $('#s_lastname').val() + '</b></li>';
            
            var li_first_name = "<li id=\"" + $('#s_firstname').val() + "\" ><b>";
			li_first_name += removefunc.getAutoCompRemoveIconElement($('#s_firstname').val(), $('#s_firstname').val(), '32');
            li_first_name += $('#s_firstname').val() + '</b></li>';
            
            var li_email = "<li id=\"" + $('#s_email').val() + "\" ><b>";
			li_email += removefunc.getAutoCompRemoveIconElement($('#s_email').val(), $('#s_email').val(), '33');
			li_email += $('#s_email').val() + '</b></li>';
        
        
		/*var li_org_name = "<li id=\"" + $("#AC_ADMIN_CD").val() + "_dscr\">";
		var li_admin_cd = "<li id=\"" + $("#AC_ADMIN_CD").val() + "\">";
		if ($('#h_readOnly').val() != 'y') {
			li_org_name += utility.getAutoCompRemoveIconElement($('#AC_ADMIN_CD').val() + '_dscr', $('#AC_ADMIN_CD_DESCR').val(), '35');
			li_admin_cd += utility.getAutoCompRemoveIconElement($('#AC_ADMIN_CD').val(), $('#AC_ADMIN_CD').val(), '25');
		}
		li_admin_cd += $('#AC_ADMIN_CD').val() + '</li>';
		li_org_name += $('#AC_ADMIN_CD_DESCR').val() + '</li>';*/
        
        $('#SUPERVISOR_LN_DISP').append(li_last_name).removeClass('hidden');
        $('#SUPERVISOR_FN_DISP').append(li_first_name).removeClass('hidden');
        $('#SUPERVISOR_EM_DISP').append(li_email).removeClass('hidden');
        
        $('#SUPERVISOR_LAST_NAME_container').addClass('hidden');
		$('#SUPERVISOR_LAST_NAME').attr('_required', 'false');
    }else{
    	$('#admin_code_section_9').addClass('hidden');
    }
    
    if ($('#o_lastname').val() != '') {
        
        	var li_last_name = "<li id=\"" + $('#o_lastname').val() + "\" ><b>";
			li_last_name += removefunc.getAutoCompRemoveIconElement($('#o_lastname').val(), $('#o_lastname').val(), '11');
            li_last_name += $('#o_lastname').val() + '</b></li>';
            
            var li_first_name = "<li id=\"" + $('#o_firstname').val() + "\" ><b>";
			li_first_name += removefunc.getAutoCompRemoveIconElement($('#o_firstname').val(), $('#o_firstname').val(), '12');
            li_first_name += $('#o_firstname').val() + '</b></li>';
            
            var li_email = "<li id=\"" + $('#o_email').val() + "\" ><b>";
			li_email += removefunc.getAutoCompRemoveIconElement($('#o_email').val(), $('#o_email').val(), '13');
			li_email += $('#o_email').val() + '</b></li>';
        
        
        $('#OFFICIAL_LN_DISP').append(li_last_name).removeClass('hidden');
        $('#OFFICIAL_FN_DISP').append(li_first_name).removeClass('hidden');
        $('#OFFICIAL_EM_DISP').append(li_email).removeClass('hidden');
        
        $('#OFFICIAL_LAST_NAME_container').addClass('hidden');
		$('#OFFICIAL_LAST_NAME').attr('_required', 'false');
    }else{
    	$('#admin_code_section_8').addClass('hidden');
    }
    
    $('#SUPERVISOR_LN_DISP').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#SUPERVISOR_LN_DISP').addClass('hidden').empty();
            $('#SUPERVISOR_FN_DISP').addClass('hidden').empty();
            $('#SUPERVISOR_EM_DISP').addClass('hidden').empty();
			$('#SUPERVISOR_LAST_NAME_container').removeClass('hidden');
			$('#SUPERVISOR_LAST_NAME').attr('_required', 'true');
            $('#admin_code_section_9').addClass('hidden');
            $('#s_lastname').val('');
            $('#s_firstname').val('');
            $('#s_email').val('');
            
		}
	});
    
    $('#SUPERVISOR_FN_DISP').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#SUPERVISOR_FN_DISP').addClass('hidden').empty();
            $('#SUPERVISOR_LN_DISP').addClass('hidden').empty();
            $('#SUPERVISOR_EM_DISP').addClass('hidden').empty();
			$('#SUPERVISOR_LAST_NAME_container').removeClass('hidden');
			$('#SUPERVISOR_LAST_NAME').attr('_required', 'true');
            $('#admin_code_section_9').addClass('hidden');
            
            $('#s_lastname').val('');
            $('#s_firstname').val('');
            $('#s_email').val('');
		}
	});

	$('#SUPERVISOR_EM_DISP').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#SUPERVISOR_EM_DISP').addClass('hidden').empty();
            $('#SUPERVISOR_LN_DISP').addClass('hidden').empty();
            $('#SUPERVISOR_FN_DISP').addClass('hidden').empty();
			$('#SUPERVISOR_LAST_NAME_container').removeClass('hidden');
			$('#SUPERVISOR_LAST_NAME').attr('_required', 'true');
            $('#admin_code_section_9').addClass('hidden');
            
            $('#s_lastname').val('');
            $('#s_firstname').val('');
            $('#s_email').val('');
		}
	});
    
    $('#OFFICIAL_LN_DISP').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#OFFICIAL_LN_DISP').addClass('hidden').empty();
            $('#OFFICIAL_FN_DISP').addClass('hidden').empty();
            $('#OFFICIAL_EM_DISP').addClass('hidden').empty();
			$('#OFFICIAL_LAST_NAME_container').removeClass('hidden');
			$('#OFFICIAL_LAST_NAME').attr('_required', 'true');
            $('#admin_code_section_8').addClass('hidden');
            
            $('#o_lastname').val('');
            $('#o_firstname').val('');
            $('#o_email').val('');
		}
	});
    
    $('#OFFICIAL_FN_DISP').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#OFFICIAL_FN_DISP').addClass('hidden').empty();
            $('#OFFICIAL_LN_DISP').addClass('hidden').empty();
            $('#OFFICIAL_EM_DISP').addClass('hidden').empty();
			$('#OFFICIAL_LAST_NAME_container').removeClass('hidden');
			$('#OFFICIAL_LAST_NAME').attr('_required', 'true');
            $('#admin_code_section_8').addClass('hidden');
            
            $('#o_lastname').val('');
            $('#o_firstname').val('');
            $('#o_email').val('');
		}
	});

	$('#OFFICIAL_EM_DISP').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#OFFICIAL_EM_DISP').addClass('hidden').empty();
            $('#OFFICIAL_LN_DISP').addClass('hidden').empty();
            $('#OFFICIAL_FN_DISP').addClass('hidden').empty();
			$('#OFFICIAL_LAST_NAME_container').removeClass('hidden');
			$('#OFFICIAL_LAST_NAME').attr('_required', 'true');
            $('#admin_code_section_8').addClass('hidden');
            
            $('#o_lastname').val('');
            $('#o_firstname').val('');
            $('#o_email').val('');
		}
	});
    
    //initPositionClassificationStandardGroup();
    
    utility.multiSelectFD('INCENTIVES_OFFERED',1);

	$("input[type=checkbox][name=INCENTIVES_OFFERED_M]").trigger("change");
    
    $('#INCENTIVES_OFFERED').attr("title", "Please select using space and arrows key.");
    
    //initPCSGA();
	utility.multiSelectFD('ADDITIONAL_RECRUIT_CHANNELS',1);
	
	$("input[type=checkbox][name=ADDITIONAL_RECRUIT_CHANNELS_M]").trigger("change");
    
    $('#ADDITIONAL_RECRUIT_CHANNELS').attr("title", "Please select using space and arrows key.");

	
	$('#addAnn').on("click", function(){
		var val = $('#SHARED_ANN_REVIEWED').val();
		if (val != '') {
			if (val.indexOf(',') != -1) {
				alert("Comma is not allowed");
			}
			else {
				var sharedAnns = $('#h_sharedAnns').val();	
				for (var i = 1 ; i < 11; i++) {
					var cnt = $('#SHARED_DP' + i)[0].childElementCount;
					if (cnt == 0) {
						if (sharedAnns!='' && sharedAnns.indexOf(val) != -1) {
							alert("Announcement already exists");
							break;
						}
						var liVal = "<li id=\"" + val + "\" ><b>";
						liVal += removefuncOf.getAutoCompRemoveIconElement(val,val, '51');
						liVal += val + '</b></li>';
						$('#SHARED_DP' + i).append(liVal).removeClass('hidden');	
						if(sharedAnns=='') {
							sharedAnns =  val;
						}
						else {
							sharedAnns = sharedAnns + ',' + val;
						}
						$('#h_sharedAnns').val(sharedAnns);
						break;
					}
				
				}
			}
			
	
		}

		// after select propagation is done to selected item checkbox list, clear current select from dropdown
		$('#SHARED_ANN_REVIEWED').val('');
	});
	$('#SHARED_DP1').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			removeSharedAnn('SHARED_DP', 1);
		}
	});
	$('#SHARED_DP2').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			removeSharedAnn('SHARED_DP', 2);
		}
	});
	$('#SHARED_DP3').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			removeSharedAnn('SHARED_DP', 3);
		}
	});
	$('#SHARED_DP4').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			removeSharedAnn('SHARED_DP', 4);	
		}
	});
	$('#SHARED_DP5').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			removeSharedAnn('SHARED_DP', 5);
		}
	});
	$('#SHARED_DP6').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			removeSharedAnn('SHARED_DP', 6);
		}
	});
	$('#SHARED_DP7').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			removeSharedAnn('SHARED_DP', 7);	
		}
	});
	$('#SHARED_DP8').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			removeSharedAnn('SHARED_DP', 8);
		}
	});
	$('#SHARED_DP9').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			removeSharedAnn('SHARED_DP', 9);	
		}
	});
	$('#SHARED_DP10').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			removeSharedAnn('SHARED_DP', 10);
			/*var sharedAnns = $('#h_sharedAnns').val();	
			if ($('#SHARED_DP10')[0].innerText.indexOf(sharedAnns.toString() + ',') != -1) {
				$('#h_sharedAnns').val(sharedAnns.replace(sharedAnns + ',',''));
			}
			else if ($('#SHARED_DP10')[0].innerText.indexOf(sharedAnns.toString()) != -1) {
				$('#h_sharedAnns').val(sharedAnns.replace(sharedAnns,''));
			}
			$('#SHARED_DP10').addClass('hidden').empty();	
			*/
		}
	});
}


var setReqNumAutoComplete = function () {
   
	$('#JOB_OPENING_ID').autocomplete({
		source: function (request, response) {
			$.ajax({
				url: base_url + 'searchReqNumber.do?searchRequestNumber=' + $('#JOB_OPENING_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						return {  
							requisitionNumber:  $( 'ID', this ).text(),
							positionTitle: $( 'JOB_TITLE', this ).text(),
							payPlan: $( 'PAY_PLAN', this ).text(),
							series: $( 'OCC_SERIES', this ).text(),
							grade: $( 'GRADE', this ).text(),
							effDate: $( 'EFF_DATE', this ).text(),
							orgInits: $( 'ORG_INITS', this ).text(),
							customer: $( 'IC', this ).text(),
							branch:  $( 'BRANCH', this ).text(),
							adminCode: $( 'ADMIN_CODE', this ).text(),
							preComment: $( 'CAPHR_COMMENTS', this ).text(),
							canNumber: $( 'CAN_NUMBER', this ).text(),
							dateJobReqApp: $( 'DATE_JOB_REQ_APPROVED', this ).text(),
							
						};
					}).get();
					response(data);
				}
			})
		},
		minLength: 2,
		change: function (e, u) {
			//If the No match found" u.item will return null, clear the TextBox.
			if (u.item == null) {
				
				//Clear the AutoComplete TextBox.
				
				var pos = $(this).position();
				$('#JOB_OPENING_ID_noMatch').remove();
				$(this).after("<span id='JOB_OPENING_ID_noMatch' class='acNoMatch'>Invalid Selection:<br />Item must be selected from the available options.</span>");
				$('#JOB_OPENING_ID_noMatch').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
				setTimeout(function() {
					$('#JOB_OPENING_ID_noMatch').remove();
				}, 2000);
				
				$('#requsitionNumber').text('');
				$(this).val('');
				$('#pv_positionTitle').val('');
				$('#pv_payPlan').val('');
				$('#pv_series').val('');
				$('#pv_grade').val('');
				$('#TransactionInfo_PED').val('');
				$('#ORG_INITS').val('');
				$('#INSTITUTE').val('');
				$('#ADMIN_CODE').val('');
				$('#pv_branch').val('');
				$('#pv_originalBranch').val('');
				$('#DATE_JOB_OPENING_APPROVED').val('');
				$('#CAN_NO').val('');
				$('#PRERECRUIT_COMMENTS').val('');
				getbranchInfo();
				
				return false;
			}
				
		},
		select: function (event, ui) {
			
			var requisitionNumber = ui.item.requisitionNumber;
			var positionTitle = ui.item.positionTitle;
			var payPlan = ui.item.payPlan;
			var series = ui.item.series;
			var grade = ui.item.grade;
			var proposedEffDateLabel = "";
			var effDateString = ui.item.effDate;
			if (effDateString != null && effDateString.length > 0) {
				var proposedEffDate = new Date(effDateString);
				proposedEffDateLabel = utility.getDateString({isUTC: false, dateFormat: 'mm/dd/yyyy'}, proposedEffDate);
			}			
			var orgInits = ui.item.orgInits;
			var customer = ui.item.customer;
			var branch = ui.item.branch;
			var adminCode = ui.item.adminCode;
		
			var preComment = ui.item.preComment;
			var canNumber = ui.item.canNumber;
			var dateJobReqAppLabel = "";
			var dateJobReqAppStr = ui.item.dateJobReqApp;
			if (dateJobReqAppStr != null && dateJobReqAppStr.length > 0) {
				var dateJobReqApp = new Date(dateJobReqAppStr);
				dateJobReqAppLabel = utility.getDateString({isUTC: false, dateFormat: 'mm/dd/yyyy'}, dateJobReqApp);
			}	
			
			$('#pv_positionTitle').val(positionTitle);
			$('#pv_payPlan').val(payPlan);
			$('#pv_series').val(series);
			$('#pv_grade').val(grade);
			$('#TransactionInfo_PED').val(proposedEffDateLabel);
			$('#ORG_INITS').val(orgInits);
			$('#INSTITUTE').val(customer);
			$('#ADMIN_CODE').val(adminCode);
			$('#pv_branch').val(branch);
			$('#pv_originalBranch').val(branch);
			$('#h_manualRequisition').val(requisitionNumber);
			$('#PRERECRUIT_COMMENTS').val(preComment);
			$('#CAN_NO').val(canNumber);
			$('#DATE_JOB_OPENING_APPROVED').val(dateJobReqAppLabel);
			
			setTimeout(function() {
					utility.greyOutScreen(true);
					WHRSCMain.tabManager.enableTabsForSubmission();
					utility.submitFormPage(null, 'saveNewForm');
			}, 0);
			
		},
	
		open: function() {
			 $('.ui-autocomplete').css('z-index', 5000);
		},
		close: function() {
			 $('.ui-autocomplete').css('z-index', 1);
		}
	
	})
		
	.autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
		return $('<li>')
			.append('<a title="' + item.requisitionNumber + '">' + item.requisitionNumber +  '</a>')
			.appendTo(ul);
	};

}

var setPrAutoComplete = function () {
   
	$('#SUPERVISOR_LAST_NAME').autocomplete({
		source: function (request, response) {
			$.ajax({
				url: base_url + 'SearchAll.do?SearchAll=' + $('#SUPERVISOR_LAST_NAME').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
                       
                        
						return {
							//ac_id: $( 'AC_ID', this ).text(),
							last_name: $( 'LNAME', this ).text(),
							first_name: $( 'FNAME', this ).text(),
							email: $( 'EMAIL', this ).text()
						};
					}).get();
					response(data);
				}
			})
		},
		minLength: 2,
		change: function (e, u) {
			//If the No match found" u.item will return null, clear the TextBox.
			if (u.item == null) {
				//Clear the AutoComplete TextBox.
				var pos = $(this).position();
				$('#SUPERVISOR_LAST_NAME_noMatch').remove();
				$(this).after("<span id='SUPERVISOR_LAST_NAME_noMatch' class='acNoMatch'>Invalid Selection:<br />Item must be selected from the available options.</span>");
				$('#SUPERVISOR_LAST_NAME_noMatch').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
				setTimeout(function() {
					$('#SUPERVISOR_LAST_NAME_noMatch').remove();
				}, 2000);
				$(this).val('');
				return false;
			}
		},
		select: function (event, ui) {
			var li_last_name = "<li id=\"" + ui.item.last_name + "\" ><b>";
			li_last_name += removefuncOf.getAutoCompRemoveIconElement(ui.item.last_name, ui.item.last_name, '51');
            li_last_name += ui.item.last_name + '</b></li>';
            
            var li_first_name = "<li id=\"" + ui.item.first_name + "\" ><b>";
			li_first_name += removefuncOf.getAutoCompRemoveIconElement(ui.item.first_name, ui.item.first_name, '52');
            li_first_name += ui.item.first_name + '</b></li>';
            
            var li_email = "<li id=\"" + ui.item.email + "\" ><b>";
			li_email += removefuncOf.getAutoCompRemoveIconElement(ui.item.email, ui.item.email, '53');
			li_email += ui.item.email + '</b></li>';

			$('#SUPERVISOR_LN_DISP').append(li_last_name).removeClass('hidden');
            $('#SUPERVISOR_FN_DISP').append(li_first_name).removeClass('hidden');
            $('#SUPERVISOR_EM_DISP').append(li_email).removeClass('hidden');
            $('#admin_code_section_9').removeClass('hidden');
			$('#SUPERVISOR_LAST_NAME_container').addClass('hidden');
			$('#SUPERVISOR_LAST_NAME').attr('_required', 'false');
            $('#s_lastname').val(ui.item.last_name);
            $('#s_firstname').val(ui.item.first_name);
            $('#s_email').val(ui.item.email);
			
		},
		open: function() {
			 $('.ui-autocomplete').css('z-index', 5000);
		},
		close: function() {
			 $('.ui-autocomplete').css('z-index', 1);
		}
	})
	.autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
		return $('<li>')
			.append('<a title="' + item.last_name + ', ' + item.first_name + '">' + item.last_name + ', ' + item.first_name +  '</a>')
			.appendTo(ul);
	};

}

var setOfAutoComplete = function () {
   
	$('#OFFICIAL_LAST_NAME').autocomplete({
		source: function (request, response) {
			$.ajax({
				url: base_url + 'SearchAll.do?SearchAll=' + $('#OFFICIAL_LAST_NAME').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
                       
                        
						return {
							//ac_id: $( 'AC_ID', this ).text(),
							last_name: $( 'LNAME', this ).text(),
							first_name: $( 'FNAME', this ).text(),
							email: $( 'EMAIL', this ).text()
						};
					}).get();
					response(data);
				}
			})
		},
		minLength: 2,
		change: function (e, u) {
			//If the No match found" u.item will return null, clear the TextBox.
			if (u.item == null) {
				//Clear the AutoComplete TextBox.
				var pos = $(this).position();
				$('#OFFICIAL_LAST_NAME_noMatch').remove();
				$(this).after("<span id='OFFICIAL_LAST_NAME_noMatch' class='acNoMatch'>Invalid Selection:<br />Item must be selected from the available options.</span>");
				$('#OFFICIAL_LAST_NAME_noMatch').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
				setTimeout(function() {
					$('#OFFICIAL_LAST_NAME_noMatch').remove();
				}, 2000);
				$(this).val('');
				return false;
			}
		},
		select: function (event, ui) {
			var li_last_name = "<li id=\"" + ui.item.last_name + "\" ><b>";
			li_last_name += removefuncOf.getAutoCompRemoveIconElement(ui.item.last_name, ui.item.last_name, '26');
            li_last_name += ui.item.last_name + '</b></li>';
            
            var li_first_name = "<li id=\"" + ui.item.first_name + "\" ><b>";
			li_first_name += removefuncOf.getAutoCompRemoveIconElement(ui.item.first_name, ui.item.first_name, '27');
            li_first_name += ui.item.first_name + '</b></li>';
            
            var li_email = "<li id=\"" + ui.item.email + "\" ><b>";
			li_email += removefuncOf.getAutoCompRemoveIconElement(ui.item.email, ui.item.email, '28');
			li_email += ui.item.email + '</b></li>';

			$('#OFFICIAL_LN_DISP').append(li_last_name).removeClass('hidden');
            $('#OFFICIAL_FN_DISP').append(li_first_name).removeClass('hidden');
            $('#OFFICIAL_EM_DISP').append(li_email).removeClass('hidden');
            $('#admin_code_section_8').removeClass('hidden');
			$('#OFFICIAL_LAST_NAME_container').addClass('hidden');
			$('#OFFICIAL_LAST_NAME').attr('_required', 'false');
            $('#o_lastname').val(ui.item.last_name);
            $('#o_firstname').val(ui.item.first_name);
            $('#o_email').val(ui.item.email);
			
		},
		open: function() {
			 $('.ui-autocomplete').css('z-index', 5000);
		},
		close: function() {
			 $('.ui-autocomplete').css('z-index', 1);
		}
	})
	.autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
		return $('<li>')
			.append('<a title="' + item.last_name + ', ' + item.first_name + '">' + item.last_name + ', ' + item.first_name +  '</a>')
			.appendTo(ul);
	};

}
var addComma2 = function(fieldval){
    var ctext = '';
    if (fieldval != undefined){
       if (fieldval != ''){
        fieldval = fieldval.replace(/\./g,'');
        var chstr = fieldval.split('');

        for ( var i in chstr ) {
         ctext += chstr[i] + '.';
        }
       }
    }
    return ctext;
};

var removefuncOf = {
    autoCompletionBaseURL: '/bizflowwebmaker/whrsc_AUT/',
    
    getAutoCompRemoveIconElement: function (target, targetDescription, tabIndex) {
        var elementString = '<img src="' + removefuncOf.autoCompletionBaseURL + 'custom/images/delete-icon.png' +
                    '" id="delete-' + target + '" deleteId="' + target +
                    '" title="Remove ' + targetDescription + '" tabindex="' + tabIndex + '" /> ';
        return elementString;
    }
};

function removeSharedAnn(name,indx){
	var innerText = $('#' +  name + indx)[0].innerText;
	innerText = innerText.replace(" ", "");
	var sharedAnns = $('#h_sharedAnns').val();	
	var split = sharedAnns.split(',');
	var splitCnt = split.length;
	for (var i=0;i <splitCnt;i++) {
		if (split[i]==innerText) {
			//if((i==0 && splitCnt == 1)|| i==splitCnt -1) {
			if(i==0 && splitCnt == 1) {
				$('#h_sharedAnns').val(sharedAnns.replace(innerText,''));
			}
			else if(i==0 && splitCnt != 1) {
				$('#h_sharedAnns').val(sharedAnns.replace(innerText + ',',''));
			}
			else if(i!=0 && i!=splitCnt -1) {
				$('#h_sharedAnns').val(sharedAnns.replace(innerText + ',',''));
			}
			else if(i!=0 && i==splitCnt -1) {
				$('#h_sharedAnns').val(sharedAnns.replace(',' + innerText,''));
			}
		}
	}
	$('#' + name + indx).addClass('hidden').empty();
}

