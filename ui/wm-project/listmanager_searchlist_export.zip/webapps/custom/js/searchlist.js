var base_url = '/bizflowwebmaker/listmanager_candidateinfo/';

$(function(){

  $("#CLEAR_BTN").hide();
  //$("#RESULTS_SECTION").hide();
  $("#PCP_LAYOUT").hide();


  //$("#SearchRefGroup").hide();
});

var searchList = function(){
  utility.multiSelectFD('PPP_LIST_NAME',1);
  $("input[type=checkbox][name=PPP_LIST_NAME_M]").trigger("change");
  $('#PPP_LIST_NAME').attr("title", "Please select using space and arrows key.");

  utility.multiSelectFD('PCP_LIST_NAME',1);
  $("input[type=checkbox][name=PCP_LIST_NAME_M]").trigger("change");
  $('#PCP_LIST_NAME').attr("title", "Please select using space and arrows key.");

  utility.multiSelectFD('SERIES',1);
  $("input[type=checkbox][name=SERIES_M]").trigger("change");
  $('#SERIES').attr("title", "Please select using space and arrows key.");

  utility.multiSelectFD('GRADE',1);
  $("input[type=checkbox][name=GRADE_M]").trigger("change");
  $('#GRADE').attr("title", "Please select using space and arrows key.");

  $('#LIST_TYPE').on("change", function(){
    if($('#LIST_TYPE').val() == 'Priority Consideration Program') {
            $('#PCP_LAYOUT').show();
            $('#PPP_LAYOUT').hide();
            $("input[type=checkbox][name=PPP_LIST_NAME_M]").removeAttr('checked').parent().parent().hide();
    } else {
            $('#PCP_LAYOUT').hide();
            $('#PPP_LAYOUT').show();
            $("input[type=checkbox][name=PCP_LIST_NAME_M]").removeAttr('checked').parent().parent().hide();
    }
	});

  $('#LATITUDE').on("change", function(){
		isLatitude();
	});
	$('#LONGITUDE').on("change", function(){
		isLongitude();
	});
  $('#SEARCH_RADIUS').on("change", function(){
    isValidRadius();
  });

  $('#WEATHER_LINK').on('click',function() {
    //var url = "https://www.weather.gov/spot/request/";
    var url = $('#h_weatherUrl').val();
    var popOption = "width=1340, height=600, top=100, left=100, resizable=yes, scrollbars=yes, status=yes";
    window.open(url,"",popOption);
  });
};
var loadingResults = function(){

  var jobReqNum = $('#JOB_REQ_NUMBER').val();
  if (jobReqNum == '') {
    $("#SEARCH_BTN").show();
    $("#CLEAR_BTN").hide();
    $("#layout_group_with_reason").hide();
    $("#GENERATE_PDF").hide();
    $('#search_ref_number_layout_group').hide();
  } else {
    $("#layout_group_no_reason").hide();
	hyf.util.disableComponent('GENERATE_PDF');


	var searchCount = $('#seachCount').val();
	for (var i=1;i <= searchCount;i++) {
		 runActionStatus(i);
	}

  }

}
var searchBtnClick = function(){

  $("#CLEAR_BTN").show();
  $("#SEARCH_BTN").hide();

	var chklatVal =  $('#LATITUDE').val();
	if(chklatVal.indexOf('.') == -1) {
		$('#LATITUDE').val(chklatVal+'.000001');
	}
	var chklonVal =  $('#LONGITUDE').val();
	if(chklonVal.indexOf('.') == -1) {
		$('#LONGITUDE').val(chklonVal+'.000001');
	}

	if ($("input[type=checkbox][name=GRADE_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
		$('#h_gradeSecVal').val('1');
	}
	else {$('#h_gradeSecVal').val('2');}
	if ($("input[type=checkbox][name=SERIES_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
		$('#h_seriesSecVal').val('1');
	}
	else {$('#h_seriesSecVal').val('2');}

};

var clearBtnClick = function(){

  $("#CLEAR_BTN").hide();
  $("#SEARCH_BTN").show();


  resetValues();

};

var generatePDFCLick = function(){

	var searchCount = $('#seachCount').val();
	for (var i=1;i < searchCount+1;i++) {
		if($('#BasicTable'+i+'REASON_CLEARED option:selected').val()=='Other'){
			if($('#BasicTable'+i+'COMMENT').val()==''){
				alert("The comments are required when the 'Reason Cleared' is 'Other'.");
			return false;
			}
		}

	}
	$("#CLEAR_BTN").hide();
	$("#SEARCH_BTN").show();
	resetValues();
	utility.greyOutScreen(true);
	return true;
};


var generatePDF = function() {
	var seach_id = $('#h_search_id').val();
	var url = "/bizflow/solutions/whrsc/listmanager/generate_pdf.jsp?param1="+seach_id;
	$("body").append("<iframe TITLE='hiddenFrame' name='hiddenFrame'  src='" + url + "'  style='display:none;'></iframe");
	utility.greyOutScreen(false);

};

function isLatitude() {
	var lat = $('#LATITUDE').val();
	var isLat = isFinite(lat) && Math.abs(lat) <= 90;
	if (isLat==false) {
		$('#LATITUDE').val('');
		alert("Please provide valid Latitude value, ##.######");
	}
};
function isLongitude() {
	var lng = $('#LONGITUDE').val();
	var isLong =  isFinite(lng) && Math.abs(lng) <= 180;
	if (isLong==false) {
		$('LONGITUDE').val('');
		alert("Please provide valid Longitude value, ###.######");
	}
};
function isValidRadius() {
	var radius = $('#SEARCH_RADIUS').val();
	var isRadius = isFinite(radius) && Math.abs(radius) <= 12450;
	if (isRadius==false || radius < 0) {
		$('#SEARCH_RADIUS').val('');
		alert("Please provide valid positive Radius value, less than 12,450 miles.");
	}
};

var mandatoryValues = function(){
  var isFull = false;
  var pppLength = $('input[type=checkbox][name=PPP_LIST_NAME_M]:checked').length;
  var pcpLength = $('input[type=checkbox][name=PCP_LIST_NAME_M]:checked').length;
  if ((pppLength > 0 || pcpLength > 0)
	    && $('#JOB_REQ_NUMBER').val() != ''
        && $('#LATITUDE').val() != ''
        && $('#LONGITUDE').val() != ''
        && $('#SEARCH_RADIUS').val() != '') {
    isFull = true;
  } else {
    alert('Please complete Mandatory Fields');
  }
  return isFull;
};

var resetValues = function(){
	$('#JOB_REQ_NUMBER').val('');
	$('#LIST_TYPE').val('');
	$('#PCP_LAYOUT').hide();
	$('#PPP_LAYOUT').show();
    //$("input[type=checkbox][name=PCP_LIST_NAME_M]").removeAttr('checked').parent().parent().hide();
	$('input:checkbox').removeAttr('checked').parent().parent().hide();
	$('#LATITUDE').val('');
	$('#LONGITUDE').val('');
	$('#SEARCH_RADIUS').val('');

	$("#RESULTS_SECTION").hide();
};

function  runActionStatus(index) {
	$('#BasicTable' + index + 'REASON_CLEARED').on('change',function() {
		var searchCount = $('#seachCount').val();
		var enableGenerateBtn = true;
		for (var i=1;i <= searchCount;i++) {
			if($('#BasicTable'+i+'REASON_CLEARED option:selected').val()==''){
				hyf.util.disableComponent('GENERATE_PDF');
				enableGenerateBtn = false;
				break;
			}
		}
		if(enableGenerateBtn==true) {
			hyf.util.enableComponent('GENERATE_PDF');
		}

	});

	$('#BasicTable' + index + 'CANDIDATE_NAME').on('click',function() {

		var candidate_id = $('#BasicTable' + index + 'CANDIDATE_ID').val();
		var popOption = "width=1024, height=576, resizable=no, scrollbars=yes, status=no;";

		var nm = "";
		var url = "../listmanager_candidateinfo/bizflowEntry.do?candidate_id="+candidate_id;

		window.open(url,"","width=1024, height=576, top=100,left=500,resizable=no, scrollbars=yes, status=no");

        //window.open(url,"",popOption);

	});
}
