var getSecurity = function(){
    //
    $('#G_DOB_calendar_anchor').attr('tabindex', 260);

    $('#G_LAST_NAME').val(opener.document.getElementById("A_NAME_INPUT").value).attr({ readonly:'readonly', style:'background-color:#efefef' });
    $('#G_FIRST_NAME').val(opener.document.getElementById("A_NAME_INPUT_F").value).attr({ readonly:'readonly', style:'background-color:#efefef' });
    $('#h_requisitionNumber').val(opener.document.getElementById("h_requisitionNumber").value);
    $('#h_transaction_id').val(opener.document.getElementById("h_transactionNumber").value);

    $('#h_idType_selected').val('SSN');
    $("#ID_TYPE").change(function() {
      var selectedID = $(this).find(':selected').val();
      $('#h_idType_selected').val(selectedID);
    });


    $('#VISA_GROUP').hide();
    $('#ALIEN_REG_GROUP').hide();
    $('#FOREIGN_ID_GROUP').hide();

    $('#ID_TYPE').on("change", function(){
      var idTypeSelected =  $('#ID_TYPE option:selected').val();
      switch (idTypeSelected){
        case 'SSN':
          $('#SSN_GROUP').show();
          $('#VISA_GROUP,#ALIEN_REG_GROUP,#FOREIGN_ID_GROUP').hide();
          $('#G_VISA,#G_ALIEN_NUM,#G_FOREIGN_ID,#G_FOREIGN_COUNTRY').val('');
          break;
        case 'VISA Number':
          $('#VISA_GROUP').show();
          $('#SSN_GROUP,#ALIEN_REG_GROUP,#FOREIGN_ID_GROUP').hide();
          $('#G_SSN,#G_ALIEN_NUM,#G_FOREIGN_ID,#G_FOREIGN_COUNTRY').val('');
          break;
        case 'Alien Registration Number':
          $('#ALIEN_REG_GROUP').show();
          $('#VISA_GROUP,#SSN_GROUP,#FOREIGN_ID_GROUP').hide();
          $('#G_VISA,#G_SSN,#G_FOREIGN_ID,#G_FOREIGN_COUNTRY').val('');
          break;
        case 'Foreign ID':
          $('#FOREIGN_ID_GROUP').show();
          $('#VISA_GROUP,#ALIEN_REG_GROUP,#SSN_GROUP').hide();
          $('#G_VISA,#G_ALIEN_NUM,#G_SSN').val('');
          break;
      }

    });

    $('<div id="overlay"/>').css({
         'background-color': '#333',
         'opacity': '0.8',
         'position': 'absolute',
         'left': '0px',
         'top': '0px',
         'z-index': '100',
         'height': '100%',
         'width': '100%',
         'overflow': 'hidden',
         'background-position': 'center',
         'background-repeat': 'no-repeat'
      }).hide().appendTo('body');

}

var mandatoryValues = function(){
  var isFull = false;
  if ( ( ($('#G_FOREIGN_ID').val() != '' &&  $('#G_FOREIGN_COUNTRY').val() != '')
          || $('#G_SSN').val() != ''
          || $('#G_VISA').val() != ''
          || $('#G_ALIEN_NUM').val() != ''
        )
        && $('#G_LAST_NAME').val() != ''
        && $('#G_FIRST_NAME').val() != ''
        && $('#G_DOB').val() != ''
        && $('#G_OPDIV').val() != ''
        && $('#G_AFFILIATION').val() != ''
      ) {
    isFull = true;
  } else {
    alert('Please complete Mandatory Fields');
  }
  return isFull;
};

var callInductionService = function(){
  var resp_hhsId = '';
  var resp_resultCode = '';
  var resp_resultMessage = '';
  var resp_failureDetailMessage = '';

  var xmlRequest = "<InductionRequest><FirstName>"+
            $('#G_FIRST_NAME').val()+"</FirstName><LastName>"+
            $('#G_LAST_NAME').val()+"</LastName><SSN>"+
            $('#G_SSN').val()+"</SSN><ARN>"+
            $('#G_ALIEN_NUM').val()+"</ARN><VisaNumber>"+
            $('#G_VISA').val()+"</VisaNumber><ForeignIdNumber>"+
            $('#G_FOREIGN_ID').val()+"</ForeignIdNumber><ForeignIdIssuingCountry>"+
            $('#G_FOREIGN_COUNTRY').find(':selected').val()+"</ForeignIdIssuingCountry><DOB>"+
            $('#G_DOB').val()+"</DOB><OPDIV>"+
            $('#G_OPDIV').find(':selected').val()+"</OPDIV><AffiliationCode>"+
            $('#G_AFFILIATION').find(':selected').val()+"</AffiliationCode></InductionRequest>";
  $.ajax({
        type: 'POST',
        url: '/scmsswsc/induction/inductPerson',
        dataType: 'application/x-www-form-urlencoded',
        data: xmlRequest,
        contentType: "application/xml",
        cache: false,
        async: false,
        success: function (xmlResponse) {
          var xmlString = xmlResponse.responseText;
          resp_hhsId = $(xmlString).find('HHSID').text();
          resp_resultCode = $(xmlString).find('ResultCode').text();
          resp_resultMessage = $(xmlString).find('ResultMessage').text();
          resp_failureDetailMessage = $(xmlString).find('FailureDetailMessage').text();
          alert ('Security Information Request has been sent.');

        },
        error: function(xmlErrorResponse) {

          var xmlString = xmlErrorResponse.responseText;
    		  resp_hhsId = $(xmlString).find('HHSID').text();
    		  resp_resultCode = $(xmlString).find('ResultCode').text();
    		  resp_resultMessage = $(xmlString).find('ResultMessage').text();
    		  resp_failureDetailMessage = $(xmlString).find('FailureDetailMessage').text();
          alert ('Error sending Security Information Request: ' + resp_failureDetailMessage);
          //opener.document.getElementById("h_wasSubmitted").value = 'false';
        }
    });
    if (resp_hhsId != '') {
      opener.document.getElementById("h_wasSubmitted").value = 'true';
      opener.document.getElementById("h_a_hhsid").value = resp_hhsId;
    }
    $('#h_hhsId').val(resp_hhsId);
    $('#h_resultCode').val(resp_resultCode);
    $('#h_resultMessage').val(resp_resultMessage);
    $('#h_failureDetailMessage').val(resp_failureDetailMessage);
};

var greyOut = function(){

  //$('#overlay').show();
  utility.greyOutScreen(true);
  $('#ID_TYPE,#G_FOREIGN_ID,#G_FOREIGN_COUNTRY,#G_VISA,#G_ALIEN_NUM,#G_SSN,#G_DOB,#G_OPDIV,#G_AFFILIATION').attr({
    readonly:'readonly', style:'background-color:#efefef'
  });

    //return false;
};

var closeWindow = function(){

  //opener.parent.location.reload();
  //alert ('HHS ID has been successfully generated. You can now close this form.');
  //opener.document.getElementById("A_NAME_INPUT_I").value = '12345678';
  //opener.document.getElementById("PSC_CLICK").innerHTML = "✔ Record linked to security";

  window.close();
};
