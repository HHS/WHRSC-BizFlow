var BFTab = (function(){
	BFTab = function(id, targetUrl, targetGroup, name, loaded, completed, disabledHeader, eventHandler, onInit){
		this.id = id;
		this.targetUrl = targetUrl;
		this.targetGroup = targetGroup;
		this.name = name;
		this.loaded = loaded;
		this.completed = completed;
		this.disabledHeader = disabledHeader;
		this.eventHandler = eventHandler;
		this.onInit = onInit;
	}
	
	return BFTab;
}());




var TabManager = (function(){

	/**
	 * Constructor for TabManager.
	 *
	 * @param tabList - array of tab specification in the following format
	 *				[
	 *					{
	 *						id: 'tab1',
	 *						targetUrl: '/eligqual/general.do',
	 *						targetGroup: 'partial_tab1',
	 *						name: 'General',
	 *						loaded: false,
	 *						completed: false,
	 *						disabledHeader: false,
	 *						eventHandler: {
	 *							// event handler definition
	 *						},
	 *						onInit: function() {
	 *							// body of code to be executed for oninit/onload of tab
	 *						}
	 *					},
	 *					{
	 *						...
	 *					}
	 *				]
	 * @param attachTabId - Tab ID for the tab for attachment, i.e. Documents tab. 
	 * @param mainFormObjName - Main form object name, e.g. WHRSCMain. 
	 * @param validateTabCustomCallback - callback function for custom tab validation.
	 *			The callback function should accept one parameter (tabId), and return true/false
	 *			to indicate the validation result. 
	 */
	TabManager = function(tabList, activityOption, attachTabId, mainFormObjName, validateTabCustomCallback){
		this.totalLoadedTabCount = 0;
		this.currentTab = '';
		this.originalTabChanger = null;
		this.tabList = (typeof tabList === 'object' && tabList != null && Array.isArray(tabList) ? tabList : []);
		this.activityOption = activityOption;
		this.attachTabId = (typeof attachTabId != 'undefined' && attachTabId != null && attachTabId.length > 0 ? attachTabId : 'NOATTACHTAB');
		this.mainFormObjName = mainFormObjName;
		this.validateTabCustomCallback = validateTabCustomCallback;
		this.tabNumberArray = [];
		
		if (tabList.length > 0){
			for (var i = 0; i < tabList.length; i++){
				this.tabNumberArray.push(i);
			}
		}
	}
	
	
	TabManager.DELETE_ICON_URI = '/bizflowwebmaker/recruitment_AUT/custom/images/delete-icon.png';
	TabManager.CURRENT_TAB_ELEMID = 'currentTabID';
	TabManager.BTN_PREVIOUS_TAB_ELEMID = 'button_Previous';
	TabManager.BTN_NEXT_TAB_ELEMID = 'button_Next';
	
	
	TabManager.prototype.getTab = function(tabID) {
		var selectedTabs = this.tabList.filter(function(node, index) {
			return node.id == tabID;
		});
		var foundTab = null;
		if (selectedTabs.length == 1) {
			foundTab = selectedTabs[0];
		}
		return foundTab;
	}

	TabManager.prototype.loadTabFromAnchor = function(node) {
		var currentTabID = this.activityOption.getCurrentTabID();
		var tabID = utility.getTabIDFromAnchor(node);
		var tab = this.getTab(tabID);

		if (tab.disabledHeader == false) {
			//if (tabID == this.attachTabId || this.isTabCompleted(currentTabID) == true) {
				this.loadTab(tabID);
			//}
		}
		// Tab click on disabled tab should be ignored.
	}

	TabManager.prototype.loadTab = function(tabID, usaData) {
		var selectedTab = this.getTab(tabID)
		if (selectedTab != null) {
			if (selectedTab.loaded == false) {
				//utility.callPartialPage(null, selectedTab.targetUrl, 'system', selectedTab.targetGroup);
				$('#h_usas_data').val(usaData);
				utility.callPartialPage(null, selectedTab.targetUrl, 'layoutForUSAS', selectedTab.targetGroup);
				selectedTab.loaded = true;
			}
		}
	}
	
	TabManager.prototype.showTabHeader = function(tabID) {
		if ($('#' + utility.getAnchorID(tabID) + ':hidden').length > 0) {
			hyf.util.showComponent('tab_control_tab_' + tabID, null, null, null);
		}
	}
	
	TabManager.prototype.hideTabHeader = function(tabID) {
		if ($('#' + utility.getAnchorID(tabID) + ':visible').length > 0) {
			hyf.util.hideComponent('tab_control_tab_' + tabID, null, null, null);
		}
	}
	
	TabManager.prototype.enableTab = function(tabID) {
		hyf.util.enableComponent(tabID);
		$('#' + tabID + ' img[src="' + TabManager.DELETE_ICON_URI + '"]').show();

		var disabledComponents = $('#' + tabID).find('input, select, textarea');
		$.each(disabledComponents, function(index, component) {
			var alwaysDisabled = $(component).attr('alwaysDisabled');
			var alwaysReadonly = $(component).attr('alwaysReadonly');
			var donotsubmit    = $(component).attr('donotsubmit');

			if (donotsubmit == 'true') {
				$(component).attr('disabled', true);
			}
			if (alwaysDisabled == 'true') {
				$(component).attr('disabled', true);
			}
			if (alwaysReadonly == 'true') {
				$(component).prop('readonly', 'true');
			}
		});
	}

	TabManager.prototype.disableTab = function(tabID) {
		hyf.util.disableComponent(tabID);
		$('#' + tabID + ' img[src="' + TabManager.DELETE_ICON_URI + '"]').hide();
	}

	TabManager.prototype.clearTabContent = function(tabID) {
		$.each($('#' + tabID + ' input.checkbox'), function(component) {
			var value = $(this).prop('checked');
			if (value == true) {
				$(this).prop('checked', false);
				$(this).trigger('change');
			}
		});
		$.each($('#' + tabID + ' input.textbox'), function(component) {
			var value = $(this).val();
			if (value && value.length > 0) {
				$(this).val('');
			}
		});

		// For Outreach tab
		$.each($('#' + tabID + ' input[type=checkbox]'), function(component) {
			$(this).prop('checked', false);
			var value = $(this).val();
			if (value && value.length > 0) {
				$(this).trigger('change');
			}
		});

		$.each($('#' + tabID + ' select'), function(component) {
			var value = $(this).val();
			if (value && value.length > 0) {
				$(this).val('');
				$(this).trigger('change');
			}
		});
		$.each($('#' + tabID + ' textarea'), function(component) {
			var value = $(this).val();
			if (value && value.length > 0) {
				$(this).val('');
			}
		});

		//TODO: callback for custom clear for each tab
	}
	
	TabManager.prototype.enableTabHeader = function(tabID) {
		var tab = this.getTab(tabID);
		if (tab != null) {
			tab.disabledHeader = false;
			var anchorID = utility.getAnchorID(tabID);
			$('#' + anchorID).removeClass('disabledTab');
			$('#' + anchorID).addClass('unselectedTab');
		} else {
			utility.debugLog('TabManager.enableTabHeader - tabID is null');
		}
	}
	
	TabManager.prototype.disableTabHeader = function(tabID) {
/*		console.log('line 214 disableTabHeader, tabID : ' + tabID);
		var tab = this.getTab(tabID);
		if (tab != null) {
			tab.disabledHeader = true;
			var anchorID = utility.getAnchorID(tabID);
			$('#' + anchorID).removeClass('unselectedTab');
			$('#' + anchorID).addClass('disabledTab');
		} else {
			utility.debugLog('TabManager.disableTabHeader - tabID is null');
		}
*/
	}
	
	TabManager.prototype.allPreviousTabCompleted = function(tabID) {
		for (var index = 0; index < this.tabList.length; index++) {
			if (this.tabList[index].id == tabID) {
				break;
			}
			if (this.tabList[index].completed == false) {
				return false;
			}
		}
		return true;
	}
	
	TabManager.prototype.validateTab = function(tabID) {
		if (isReadOnly() == false) {
			var validationResult = hyf.validation.validateContainer(document.getElementById(tabID));
			var validationResultTabCustom = true;
			if (typeof this.validateTabCustomCallback == 'function' && this.validateTabCustomCallback != null) {
				validationResultTabCustom = this.validateTabCustomCallback(tabID);
			}
			return validationResult && validationResultTabCustom;
		} else {
			return true;
		}
	}
	
	TabManager.prototype.loadNextTab = function() {
		var currentTabID = this.activityOption.getCurrentTabID();
		if (currentTabID != null) {
			var nextTabID = this.activityOption.getNextTabID(currentTabID);
			if (nextTabID != null) {
				if (this.validateTab(currentTabID) == true) {
					var nextTabID = this.activityOption.getNextTabID(currentTabID);
					while (nextTabID != null) {
						this.enableTabHeader(nextTabID);
						if (this.isTabCompleted(nextTabID) == true) {
							nextTabID = this.activityOption.getNextTabID(nextTabID);
						} else {
							break;
						}
					}
					nextTabID = this.activityOption.getNextTabID(currentTabID);
					$('#' + utility.getAnchorID(nextTabID)).click();
				} else {
					var nextTabID = this.activityOption.getNextTabID(currentTabID);
					while (nextTabID != null) {
						if (nextTabID != this.attachTabId) {
							this.disableTabHeader(nextTabID);
							nextTabID = this.activityOption.getNextTabID(nextTabID);
						} else {
							nextTabID = null;
						}
					}
				}
			}
		}
	}
	
	TabManager.prototype.loadPreviousTab = function() {
		var currentTabID = this.activityOption.getCurrentTabID();
		if (currentTabID != null) {
			var previousTabID = this.activityOption.getPreviousTabID(currentTabID);
			while (previousTabID != null) {
				var tab = this.getTab(previousTabID);
				if (tab.disabledHeader == false) {
					$('#' + utility.getAnchorID(previousTabID)).click();
					break;
				} else {
					previousTabID = this.activityOption.getPreviousTabID(previousTabID);
				}
			}
		}
	}
	
	TabManager.prototype.isTabCompleted = function(tabID) {
		var tab = this.getTab(tabID);
		var container = document.getElementById(tabID);
		var fv = hyf.FMAction.getFormValidator();
		var errors = fv.checkContainer(container);

		if (errors.length > 0) {
			tab.completed = false;
		} else {
			tab.completed = true;
		}
		return tab.completed;
	}

	TabManager.prototype.disableTabBasedOnActivityName = function(tabID, activityName) {
		// Disable tab based on BFActivityOption
		var foundActivity = this.activityOption.actList.filter(function(node, index) {
			return node.name == activityName;
		})
		if (foundActivity.length > 0) {
			var readonlyTab = foundActivity[0].readonly.filter(function(node, index) {
				return node == tabID;
			});

			if (readonlyTab.length > 0) {
				this.disableTab(tabID);
			}
		}
	}

	// This function will be called after each tab is loaded.
	TabManager.prototype.initTabAfterLoad = function(totalTabCount, tabID, activityName) {
		this.disableTabBasedOnActivityName(tabID, activityName);

		var tab = this.getTab(tabID);
		if (tab.onInit != null) {
			tab.onInit();
		}

		tab.completed = this.isTabCompleted(tabID);

		this.totalLoadedTabCount += 1;
		if (this.totalLoadedTabCount == totalTabCount) {
			this.initTabsAfterAllTabLoaded();
		}
	}
	
	TabManager.prototype.resetTabs = function() {
		var activeTabID = this.activityOption.getCurrentTabID();
		hyf.util.setFieldValue('tab_control', activeTabID);

		var activeTabs = this.activityOption.getActiveTabList(this.activityOption.getActivityName());
		var leftTabNotCompleted = false;
		for (var index = 0; index < activeTabs.length; index++) {
			var currentTabCompleted = this.isTabCompleted(activeTabs[index]);
			var previousTabCompleted = (index > 0) ? this.isTabCompleted(activeTabs[index - 1]) : true;

			if (index == 0) {
				this.enableTabHeader(activeTabs[index]);
				document.getElementById(utility.getAnchorID(activeTabs[index])).className = 'selectedTab';
			} else {
				if (leftTabNotCompleted == true) {
					if (activeTabs[index] == this.attachTabId) {
						this.enableTabHeader(activeTabs[index]);
					} else {
						this.disableTabHeader(activeTabs[index]);
					}

				} else {
					this.enableTabHeader(activeTabs[index]);
				}
			}
			if (currentTabCompleted == false) {
				leftTabNotCompleted = true;
			}
		}
	}
	

	// This function will be called after all tabs are loaded.
	TabManager.prototype.initTabsAfterAllTabLoaded = function() {
		this.initMaxSize();
		utility.setDateIconTabOrder();

		//$(document).trigger('CMS_ALL_TAB_LOADED');
		//utility.infoLog('CMS_ALL_TAB_LOADED triggered.');

		var activityName = this.activityOption.getActivityName();
		var tabs = this.activityOption.getActiveTabList(activityName);

		tabs.forEach(function(tab) {
			this.disableTabBasedOnActivityName(tab, activityName);
		}, this);  //CAUTION: this context change
		this.resetTabs();

		// keep the current tab selection
		var storedTabID = $('#'+TabManager.CURRENT_TAB_ELEMID).val();
		if (storedTabID) {
			var tab = this.getTab(storedTabID);
			if (tab.disabledHeader == false) {
				this.tabChanger(storedTabID);
				this.showHidePreNextButtons();

				$('#' + utility.getAnchorID(storedTabID)).focus();
			}
			$('#'+TabManager.CURRENT_TAB_ELEMID).val(''); // clear current tab for closing page
					utility.greyOutScreen(false);

		}

		//TODO:showHideTab callback
		//StratConMAIN.showHideTabsUponRequestType();
		if ($('#A_ADDITIONAL_APPROVAL_REQ').val() == 'No'){
            WHRSCMain.setAlwaysReadonly('AP_DATE_PKG_SENT');    
            $('#AP_DATE_PKG_SENT').css('background-color', '#efefef');
        	$('#AP_DATE_PKG_SENT').css('width', 400);
            $('#AP_DATE_PKG_SENT_calendar_anchor').addClass('hidden');
        
        	WHRSCMain.setAlwaysReadonly('AP_DATE_APP_DEC_REC');    
            $('#AP_DATE_APP_DEC_REC').css('background-color', '#efefef');
        	$('#AP_DATE_APP_DEC_REC').css('width', 400);
            $('#AP_DATE_APP_DEC_REC_calendar_anchor').addClass('hidden');
		}
		utility.greyOutScreen(false);

		//TODO: modificationRequested callback
		//var modificationRequested = $('#h_modifyRequested').val();
		//if (modificationRequested == 'true') {
		//	StratConMAIN.enableForModification();
		//}

		//TODO: alertMessage callback
		//var alertMessage = $('#pv_alertMessage').val();
		//if (alertMessage != null && alertMessage.length > 0) {
		//	StratConMAIN.showAlertMessage(alertMessage);
		//	$('#pv_alertMessage').val('');
		//}
	}
	
	// This function should be called before loading tabs.
	// This function is to add TabManager.initTabAfterLoad function to each tabs so that initTabAfterLoad can be called.
	TabManager.prototype.initResponseHandler = function(totalTabCount) {
		if (window != null) {
			var activityName = this.activityOption.getActivityName();
			var currentMainFormObjName = this.mainFormObjName;
			this.tabList.forEach(function(tab) {
				window[tab.targetGroup + 'ManipulateResponse'] = function(content, flag) {
					//CAUTION: this context change
					content = content + '<div><script type="text/javascript">function ' + tab.targetGroup +
						'_processAfterLoad() {' + currentMainFormObjName + '.tabManager.initTabAfterLoad(' + totalTabCount + ',"' + tab.id + '","' + activityName + '" );};' +
						'hyf.attachEventHandler(window, "onload",' + tab.targetGroup + '_processAfterLoad);</script></div>';
					return content;
				}
			}, this);  //CAUTION: this context change
		} else {
			utility.debugLog('TabManager - initResponseHandler - window is null.');
		}
	}

	// Sometimes webmaker loses _hyfCondDisplayIds property that affects tab behavior.
	// If it is not found, this property should be reinitialized to have the array of numbers from 0 to 8.
	TabManager.prototype.ensureTabControlPropertyPopulated = function() {
		try {
			var hyfCondDisplayIDs = $('#tab_control')[0]._hyfCondDisplayIds;
			if (!hyfCondDisplayIDs) {
				$('#tab_control')[0]._hyfCondDisplayIds = this.tabNumberArray;
			} else {
				if (hyfCondDisplayIDs.length <= 0) {
					$('#tab_control')[0]._hyfCondDisplayIds = this.tabNumberArray;
				}
			}
		} catch (e) {
		}
	}

	// This function is called whenever webmaker tab is clicked.
	// WebMaker form has default tabChanger function and this is custom one.
	TabManager.prototype.tabChanger = function(value) {
		if (this.currentTab == value) {
			return;
		};
		this.currentTab = value;

		this.ensureTabControlPropertyPopulated();
		this.resetTabs();

		var currentTabID = this.activityOption.getCurrentTabID();
		var activeTabs = this.activityOption.getActiveTabList(this.activityOption.getActivityName());
		if (this.isTabCompleted(currentTabID) == true) {
			hyf.util.setFieldValue('tab_control', value);
			this.tabList.forEach(function(tab) {
				if (tab.disabledHeader == false) {
					document.getElementById(utility.getAnchorID(tab.id)).className = 'unselectedTab';
				}
			});

			//var requestNumber = $('#h_requestNumber').val();
			//if (isReadOnly() == false) {
			//	if (requestNumber == null || requestNumber.length == 0) {
			//		$('#h_now').val(utility.getNowUTCString());
			//		utility.callPartialPage(null, 'getRequestNumber.do', 'system', 'layoutForResponse');
			//	};
			//}
			document.getElementById(utility.getAnchorID(value)).className = 'selectedTab';
		} else {
			if (isReadOnly() == false) {
				var nextTabID = this.activityOption.getNextTabID(currentTabID);
				while (nextTabID != null) {
					if (nextTabID != this.attachTabId) {
						this.disableTabHeader(nextTabID);
						nextTabID = this.activityOption.getNextTabID(nextTabID);
					} else {
						hyf.util.setFieldValue('tab_control', value);
						this.tabList.forEach(function(tab) {
							if (tab.disabledHeader != true) {
								document.getElementById(utility.getAnchorID(tab.id)).className = 'unselectedTab';
							}
						});
						document.getElementById(utility.getAnchorID(value)).className = 'selectedTab';
						nextTabID = null;
					}
				}
				// If destination tab is in left side
				if (value < currentTabID) {
					hyf.util.setFieldValue('tab_control', value);
					this.tabList.forEach(function(tab) {
						if (tab.disabledHeader == false) {
							document.getElementById(utility.getAnchorID(tab.id)).className = 'unselectedTab';
						}
					});

					document.getElementById(utility.getAnchorID(value)).className = 'selectedTab';
				} else {
					if (typeof event != 'undefined' && event != null) {
						event.preventDefault();
					}
				}
			}
		}

		// Broadcast ON_TAB_CHANGE event.
		// Attachment controller in document tab is using this event to update mandatory document type list.
		$(document).trigger('ON_TAB_CHANGE');
		return false;
	}
	
	TabManager.prototype.showHidePreNextButtons = function() {
		var selectedTabID = this.activityOption.getCurrentTabID();
		var activeTabs = this.activityOption.getActiveTabList();

		var currentTabIndex = 0;
		for (var index = 0; index < activeTabs.length; index++) {
			if (activeTabs[index] == selectedTabID) {
				currentTabIndex = index;
				break;
			}
		}

		if (currentTabIndex == 0) {
			hyf.util.disableComponent(TabManager.BTN_PREVIOUS_TAB_ELEMID);
			hyf.util.enableComponent(TabManager.BTN_NEXT_TAB_ELEMID);
		} else if (currentTabIndex == activeTabs.length - 1) {
			hyf.util.enableComponent(TabManager.BTN_PREVIOUS_TAB_ELEMID);
			hyf.util.disableComponent(TabManager.BTN_NEXT_TAB_ELEMID);
		} else {
			utility.enableComponents([TabManager.BTN_PREVIOUS_TAB_ELEMID, TabManager.BTN_NEXT_TAB_ELEMID])
		}
	}
	
	TabManager.prototype.installCustomTabChanger = function() {
		if (window.tab_controlTabChange != null) {
			this.originalTabChanger = window.tab_controlTabChange;
			var thisObj = this;
			window.tab_controlTabChange = function(value) {
				//CAUTION: this context change, so, replaced with thisObj
				var tab = thisObj.getTab(value);
				if (tab.disabledHeader == false) {
					thisObj.tabChanger(value);
					thisObj.showHidePreNextButtons();
					if (isReadOnly() == false) {
						thisObj.enableTabsForSubmission();
						utility.callPartialPage(null, 'saveTabContent.do', null, 'layoutForResponse2');
						thisObj.rollbackTabsAfterSubmission();
					}
				}
			}
		}
	}
	
	TabManager.prototype.setTabListOption = function(tabListOption) {
		if (tabListOption != null && tabListOption.length > 0) {
			this.tabList = tabListOption;
		} else {
			utility.logError('Tab list is null or empty.')
		}
	}
	
	TabManager.prototype.initTab = function(tabListOption, usasData) {
		utility.debugLog('TabManager - initTab');
		this.setTabListOption(tabListOption);
		var activityName = this.activityOption.getActivityName();
		var currentActivityOption = this.activityOption.getCurrentActivityOption(activityName);
		this.initResponseHandler(this.tabList.length);

		this.totalLoadedTabCount = 0;
		this.tabList.forEach(function(tab, index) {
			$('#' + utility.getAnchorID(tab.id)).attr('tabindex', index + 1);
			if (index == 0) {
				hyf.util.setFieldValue('tab_control', tab.id);
			} else {
				// Enable document tab always
				if (tab.id != this.attachTabId) {
					this.disableTabHeader(tab.id);
				}
			}
			setTimeout(this.loadTab(tab.id, usasData), 0);
		}, this);  //CAUTION: this context change

		var firstTab = true;
		// Hide Tabs
		this.tabList.forEach(function(item) {
			var showTabs = currentActivityOption.tabs.filter(function(showTabName, index) {
				return showTabName == item.id;
			});
			if (showTabs.length == 0) {
				this.hideTabHeader(item.id);
			} else {
				this.showTabHeader(item.id);
				if (firstTab == true) {
					firstTab = false;
					document.getElementById(utility.getAnchorID(item.id)).className = 'selectedTab';
					if (item.id != 'tab1') {
						document.getElementById(utility.getAnchorID('tab1')).className = 'unselectedTab';
					}
				} else {
					document.getElementById(utility.getAnchorID(item.id)).className = 'unselectedTab';
				}
			}
		}, this);  //CAUTION: this context change

		var thisObj = this;
		$('.tabContainer a').off('click').on('click', function(e) {
			e.preventDefault();
			//CAUTION: this context change
			thisObj.loadTabFromAnchor(this);
		});
		$('#'+TabManager.BTN_PREVIOUS_TAB_ELEMID).off('click').on('click', function() {
			//CAUTION: this context change
			thisObj.loadPreviousTab();
		});
		$('#'+TabManager.BTN_NEXT_TAB_ELEMID).off('click').on('click', function() {
			//CAUTION: this context change
			thisObj.loadNextTab();
		});
	}
	
	TabManager.prototype.enableATabForSubmission = function(tabID) {
		var disabledComponents = $('#' + tabID + ' input[readonly], input[disabled], select[disabled], textarea[disabled]');
		$.each(disabledComponents, function(index, component) {
			var disabledAttribute = $(this).attr('disabled');
			var readOnlyAttribute = $(this).attr('readonly');
			var donotsubmit = $(this).attr('donotsubmit');

			if (donotsubmit != 'true') {
				if (disabledAttribute) {
					$(this).removeAttr('disabled');
					$(this).attr('orgDisabled','disabled');
				}
				if (readOnlyAttribute) {
					$(this).removeAttr('readonly');
					$(this).attr('orgReadonly', 'readonly');
				}
			}
		});
	}
	
	TabManager.prototype.updateAllProcessvariable = function() {

		$('#pv_requistionNumber').val($('#A_CAP_HR_JOB_REQ').val());

		//$('#pv_branch').val($('#h_branch').val());
		
		$('#pv_hrBranchChief').val($('#h_branchChief').val());
		$('#pv_hrBranchChiefName').val($('#h_branchChiefName').val());
		$('#pv_hrBranchChiefEmail').val($('#h_branchChiefEmail').val());

		$('#pv_hrTeamLeaderEmail').val($('#h_teamLeaderEmail').val());
		$('#pv_hrTeamLeader').val($('#h_teamLeader').val());
		$('#pv_hrTeamLeaderName').val($('#h_teamLeaderName').val());

		$('#pv_hrSeniorAdvisor').val($('#h_hrSeniorAdvisor').val());
 		$('#pv_hrSeniorAdvisorName').val($('#h_hrSeniorAdvisorName').val());
		$('#pv_hrSeniorAdvisorEmail').val($('#h_hrSeniorAdvisorEmail').val());

		$('#pv_hrSpecialistName').val($('#h_hrSpecialistName').val());
		$('#pv_hrSpecialistEmail').val($('#h_hrSpecialistEmail').val()); 
		$('#pv_hrSpecialist').val($('#h_hrSpecialist').val()); 

		$('#pv_hrAssistant').val($('#h_hrAssistant').val());
		$('#pv_hrAssistantName').val($('#h_hrAssistantName').val());
		$('#pv_hrAssistantEmail').val($('#h_hrAssistantEmail').val());

		$('#pv_hrSpa').val($('#h_hrSpa').val());
		$('#pv_hrSpaName').val($('#h_hrSpaName').val());
		$('#pv_hrSpaEmail').val($('#h_hrSpaEmail').val());

		$('#pv_hrDeSelApprover').val($('#h_hrDeSelApprover').val());
		$('#pv_hrDeSelApproverEmail').val($('#h_hrDeSelApproverEmail').val());
		$('#pv_hrDeSelApproverName').val($('#h_hrDeSelApproverName').val());

		$('#pv_liasionEmail').val($('#h_email').val());
		//$('#pv_selectingOfficialEmail').val($('#o_email').val());
		$('#pv_supervisorEmail').val($('#h_a_supervisor_email').val());

		$('#pv_customerCenter').val($('#INSTITUTE').val());
		$('#pv_orgInit').val($('#ORG_INITS').val());
		$('#pv_priority').val($('#PRIORITY').val());
		$('#pv_adminCode').val($('#ADMIN_CODE').val());
		
		var proposedEffDateString = $('#PROPOSED_EFF_DATE').val();
		if (proposedEffDateString != null && proposedEffDateString.length > 0) {
			$('#pv_proposedEffDateStr').val(proposedEffDateString);
			var proposedEffDate = new Date(proposedEffDateString);  
			proposedEffDate = utility.getDateString({isUTC: true, dateFormat: 'yyyy/mm/dd hh:MM:ss'}, proposedEffDate);
			$('#pv_proposedEffDate').val(proposedEffDate);
		}

		$('#pv_firstName').val($('#h_a_emp_firstname').val());
		$('#pv_lastName').val($('#h_a_emp_lastname').val());

		$('#pv_requestedGrade').val($('#A_GRADE').val());
		$('#pv_requestedPayPlan').val($('#A_PAY_PLAN').val());
		$('#pv_requestedPositionTitle').val($('#A_POSITION_TITL').val());
		$('#pv_requestedSeries').val($('#A_SERIES').val());
		$('#pv_requestedBand').val($('#A_PAY_BAND').val());
		
		$('#pv_announcementNumber').val($('#A_ANNOUNCEMENT').val());
		$('#pv_certNumber').val($('#A_CERTIFICATE_NO').val());

		var addInfoNeeded = $('#AP_ADD_DEU_SEL_INFO').val();
		if(addInfoNeeded!='') {
			var addInfoNeededCount = addInfoNeeded.length;
			if(addInfoNeededCount > 1993) {
				addInfoNeeded = addInfoNeeded.substring(0, 1993);
				addInfoNeeded += '....END';
				$('#pv_deAdditionalInfoNeeded').val(addInfoNeeded);
			}
			else 
				$('#pv_deAdditionalInfoNeeded').val($('#AP_ADD_DEU_SEL_INFO').val());
		}
		else	 $('#pv_deAdditionalInfoNeeded').val('');

		

		var decisionComm = $('#AP_DEU_SEL_DECISION_COM').val();
		if(decisionComm!='') {
			var decisionCommCount = decisionComm.length;
			if(decisionCommCount > 1993) {
				decisionComm = decisionComm.substring(0, 1993);
				decisionComm += '....END';
				$('#pv_deDecisionComments').val(decisionComm);
			}
			else 
				$('#pv_deDecisionComments').val($('#AP_DEU_SEL_DECISION_COM').val());
		}
		else	 $('#pv_deDecisionComments').val('');
		
		var transactionInfoComm = $('#COMMENTS_STATUS').val();
		if(transactionInfoComm!='') {
			var transactionInfoCommCount = transactionInfoComm.length;
			if(transactionInfoCommCount > 1993) {
				transactionInfoComm = transactionInfoComm.substring(0, 1993);
				transactionInfoComm += '....END';
				$('#pv_transactionInfoComments').val(transactionInfoComm);
			}
			else 
				$('#pv_transactionInfoComments').val($('#COMMENTS_STATUS').val());

		}
		else	 $('#pv_transactionInfoComments').val('');

		$('#pv_missingDocs').val($('#MISSING_DOCS').val());

		var initEmail = $('#pv_initiatorEmail').val();
		if(initEmail =='') {
			$.ajax({
				url: '/bizflowwebmaker/whrsc_AUT/getUserEmail.do?memberID=' + $('#h_initiator').val(),
				dataType: 'xml',
					async: false,
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#pv_initiatorEmail').val($( 'EMAIL', this ).text());
					}).get();
					
				}
			});	
		}
		var isBenefits = $('#A_ELIGIBLE_FOR_BENEFITS').val();
		if(isBenefits=='Yes') {
			$('#pv_initiateBenefits').val('Yes');
		}
		else
			$('#pv_initiateBenefits').val('No');
		
	}

	TabManager.prototype.preprocessFieldData = function() {
	}
	TabManager.prototype.postprocessFieldData = function() {
	}

	TabManager.prototype.enableTabsForSubmission = function() {
        this.preprocessFieldData();
		var activityName = this.activityOption.getActivityName();
		var activeTabs = this.activityOption.getActiveTabList(activityName);
		activeTabs.forEach(function(tab) {
			this.enableATabForSubmission(tab);
		}, this);  //CAUTION: this context change
		this.updateAllProcessvariable();
	}

	TabManager.prototype.rollbackTabsAfterSubmission = function() {
		var targetComponents = $('input[orgDisabled], input[orgReadonly], select[orgDisabled], select[orgReadonly], textarea[orgDisabled], textarea[orgReadonly]');
		$.each(targetComponents, function(index, component) {
			var orgDisabled = $(this).attr('orgDisabled');
			var orgReadonly = $(this).attr('orgReadonly');
			var donotsubmit = $(this).attr('donotsubmit');

			if (donotsubmit != 'true') {
				if (orgDisabled) {
					$(this).attr('disabled', true);
					$(this).removeAttr('orgDisabled');
				}
				if (orgReadonly) {
					$(this).attr('readonly', true);
					$(this).removeAttr('orgReadonly');
				}
			}
		});
		this.postprocessFieldData();
	}
	
	TabManager.prototype.initMaxSize = function() {
		var tabs = this.activityOption.getActiveTabList();
		tabs.forEach(function(tab) {
			utility.initMaxSizePerTab(tab);
		});
	}
	
	
	return TabManager;

}());