var base_url = '/bizflowwebmaker/whrsc_AUT/';
var checkAppLevel = 1;
var programApproval = function(){
    
    changeAcronyms('AP_PROGRAM');
    for (var aidx = 1; aidx <= 10 ; aidx ++){
        /*var uidx = aidx - 1;
        var bidx = aidx + 1;
        
        if (chkMselectVal('AP_APPROVER' + aidx + '') == 0){
        	$('#approver_group_' + aidx + '').addClass('hidden');
        }*/
        
        $('#AP_APPROVER' + aidx).attr("title", "Please select using space and arrows key.");
        
        utility.multiSelectFD('AP_APPROVER' + aidx + '',0);
        $("input[type=checkbox][name=AP_APPROVER" + aidx + "_M]").trigger("change");
        /*$('#level_button_' + aidx).on("click", function(){
            $('#approver_group_' + bidx).removeClass('hidden');
    		$('#level_button_' + aidx).addClass('hidden');
    		$('#delete_button_' + aidx).addClass('hidden');            
        });
        $('#delete_button_' + aidx + '').on("click", function(){
             $('#approver_group_' + aidx + '').addClass('hidden');
            $('#level_button_' + uidx + '').removeClass('hidden');
            $("input[type=checkbox][name=AP_APPROVER" + aidx + "_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
            var chkMsize =  $("#AP_APPROVER" + aidx + " option").size();
            for (var ij = 1 ; ij <= chkMsize - 1; ij++){
                $('#AP_APPROVER' + aidx + '_M' + ij).attr('checked',false); 
            }
        });*/
    }
    

    searchForProgram();
    
    
    $('#level_button_1').on("click", function(){
  		$('#approver_group_2').removeClass('hidden');
        $('#level_button_1').addClass('hidden');
        checkAppLevel = 2;
    });
    

    $('#level_button_2').on("click", function(){
          $('#approver_group_3').removeClass('hidden');
        $('#level_button_2').addClass('hidden');
        $('#delete_button_2').addClass('hidden');
        checkAppLevel = 3;
    });
    $('#delete_button_2').on("click", function(){
         $('#approver_group_2').addClass('hidden');
        $('#level_button_1').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER2_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER2 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER2_M' + ij).attr('checked',false); 
		}
        checkAppLevel = 1;
    });
    
    $('#level_button_3').on("click", function(){
          $('#approver_group_4').removeClass('hidden');
        $('#level_button_3').addClass('hidden');
        $('#delete_button_3').addClass('hidden');
        checkAppLevel = 4;
    });
    $('#delete_button_3').on("click", function(){
         $('#approver_group_3').addClass('hidden');
        $('#level_button_2').removeClass('hidden');
        $('#delete_button_2').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER3_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER3 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER3_M' + ij).attr('checked',false); 
		}
        checkAppLevel = 2;
    });
    

    $('#level_button_4').on("click", function(){
          $('#approver_group_5').removeClass('hidden');
        $('#level_button_4').addClass('hidden');
        $('#delete_button_4').addClass('hidden');
        checkAppLevel = 5;
    });
    $('#delete_button_4').on("click", function(){
         $('#approver_group_4').addClass('hidden');
        $('#level_button_3').removeClass('hidden');
        $('#delete_button_3').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER4_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER4 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER4_M' + ij).attr('checked',false); 
		}
        checkAppLevel = 3;
    });
    
    $('#level_button_5').on("click", function(){
          $('#approver_group_6').removeClass('hidden');
        $('#level_button_5').addClass('hidden');
        $('#delete_button_5').addClass('hidden');
        checkAppLevel = 6;
    });
    $('#delete_button_5').on("click", function(){
         $('#approver_group_5').addClass('hidden');
        $('#level_button_4').removeClass('hidden');
        $('#delete_button_4').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER5_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER5 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER5_M' + ij).attr('checked',false); 
		}
        checkAppLevel = 4;
    });

    $('#level_button_6').on("click", function(){
          $('#approver_group_7').removeClass('hidden');
        $('#level_button_6').addClass('hidden');
        $('#delete_button_6').addClass('hidden');
        checkAppLevel = 7;
    });
    $('#delete_button_6').on("click", function(){
         $('#approver_group_6').addClass('hidden');
        $('#level_button_5').removeClass('hidden');
        $('#delete_button_5').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER6_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER6 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER6_M' + ij).attr('checked',false); 
		}
        checkAppLevel = 5;
    });
    
    $('#level_button_7').on("click", function(){
          $('#approver_group_8').removeClass('hidden');
        $('#level_button_7').addClass('hidden');
        $('#delete_button_7').addClass('hidden');
        checkAppLevel = 8;
    });
    $('#delete_button_7').on("click", function(){
         $('#approver_group_7').addClass('hidden');
        $('#level_button_6').removeClass('hidden');
        $('#delete_button_6').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER7_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER7 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER7_M' + ij).attr('checked',false); 
		}
        checkAppLevel = 6;
    });
    
    $('#level_button_8').on("click", function(){
          $('#approver_group_9').removeClass('hidden');
        $('#level_button_8').addClass('hidden');
        $('#delete_button_8').addClass('hidden');
        checkAppLevel = 9;
    });
    $('#delete_button_8').on("click", function(){
         $('#approver_group_8').addClass('hidden');
        $('#level_button_7').removeClass('hidden');
        $('#delete_button_7').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER8_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER8 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER8_M' + ij).attr('checked',false); 
		}
        checkAppLevel = 7;
    });
    
    $('#level_button_9').on("click", function(){
          $('#approver_group_10').removeClass('hidden');
        $('#level_button_9').addClass('hidden');
        $('#delete_button_9').addClass('hidden');
        checkAppLevel = 10;
    });
    $('#delete_button_9').on("click", function(){
         $('#approver_group_9').addClass('hidden');
        $('#level_button_8').removeClass('hidden');
        $('#delete_button_8').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER9_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER9 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER9_M' + ij).attr('checked',false); 
		}
        checkAppLevel = 8;
    });
    
    $('#delete_button_10').on("click", function(){
         $('#approver_group_10').addClass('hidden');
        $('#level_button_9').removeClass('hidden');
        $('#delete_button_9').removeClass('hidden');
        $("input[type=checkbox][name=AP_APPROVER10_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
        var chkMsize =  $("#AP_APPROVER10 option").size();
		for (var ij = 1 ; ij <= chkMsize - 1; ij++){
			$('#AP_APPROVER10_M' + ij).attr('checked',false); 
		}
        checkAppLevel = 9;
    });

}

function chkMselectVal(mselectName){
    
    var ct_deter =  $("#" + mselectName + " option").size();
    
    var chkmulti = 0;
				
	for (var ij = 1 ; ij <= ct_deter - 1; ij++){
					
        if($("#" + mselectName + "_M" + ij).prop('checked') == true){
            chkmulti = chkmulti + 1;
        }
					
	}
    	return chkmulti;   
    
}

function searchForProgram(){
    
    for (var k=1;k<=10;k++){
        $('#approver_group_' + k).addClass('hidden');
        $('#level_button_' + k).addClass('hidden');
        if (k < 10){
        	$('#delete_button_' + k).addClass('hidden');
        }
        $("input[type=checkbox][name=AP_APPROVER" + k + "_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().hide();
            var chkMsize =  $("#AP_APPROVER" + k + " option").size();
            for (var ij = 1 ; ij <= chkMsize - 1; ij++){
                $('#AP_APPROVER' + k + '_M' + ij).attr('checked',false); 
            }
	}
    
	$.ajax({
				url: base_url + 'levelSearch.do?LevelSearch=' + $('#AP_PROGRAM').val(),
				dataType: 'xml',
            	async: false,
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
                       return {
							ap_approver1: $( 'AP_APPROVER1_M', this ).text(),
							ap_approver2: $( 'AP_APPROVER2_M', this ).text(),
							ap_approver3: $( 'AP_APPROVER3_M', this ).text(),
                           	ap_approver4: $( 'AP_APPROVER4_M', this ).text(),
                            ap_approver5: $( 'AP_APPROVER5_M', this ).text(),
                            ap_approver6: $( 'AP_APPROVER6_M', this ).text(),
                            ap_approver7: $( 'AP_APPROVER7_M', this ).text(),
                            ap_approver8: $( 'AP_APPROVER8_M', this ).text(),
                            ap_approver9: $( 'AP_APPROVER9_M', this ).text(),
                            ap_approver10: $( 'AP_APPROVER10_M', this ).text()
						};
					}).get();
					
                    if (data != ''){
                        
                        var levelResult = objectToArray(data[0]);
                        console.log(levelResult);
                        
                        for (var y = 0; y < levelResult.length; y++) {
                            var dataNum = y + 1;                           
                            
                            if (levelResult[y] == ''){
                                //$('#approver_group_' + dataNum).addClass('hidden');
                                checkAppLevel = y;
                                break;
                            }else{
                                $('#approver_group_' + dataNum).removeClass('hidden');
                                	var arrTemp = levelResult[y],
                                    tempobj = [],
                                    parts = levelResult[y].split(",");

                                    for (var i = 0; i < parts.length; i++) {
                                       var selChkElms = $('input[type=checkbox][name=AP_APPROVER' + dataNum + '_M][value=\"' + parts[i] + '\"]');
                                            if (selChkElms.length > 0) {  // the length should really be 1 if correctly identified
                                                selChkElms.prop("checked", true);
                                                $("label[for=" + selChkElms[0].id + "]").parent().removeClass("selected");
                                                $("label[for=" + selChkElms[0].id + "]").parent().addClass("selected");
                                                selChkElms.parent().parent().show();  // show parent/parent <tr><td><input ...
                                            }
                                            $("input[type=checkbox][name=AP_APPROVER" + dataNum + "_M]").trigger("change");

                                    }
                                	if (levelResult[dataNum] == ''){
                                        for (var lastNum = dataNum; lastNum <= 10 ; lastNum ++){
                                            $('#level_button_' + lastNum).removeClass('hidden');
                                            $('#delete_button_' + lastNum).removeClass('hidden');
                                        }
                                    }

                            	}
                           }
                                               
                        }
                        
                    }
                        
				
			});
	return true;

}
function submitFormApprover(){
    var ret = true;
    		for (var cmt = 10;cmt >= 1;cmt--){
                    
                    var chkMresult = 0;
                	var nchkMresult = 0;
                    
                    var ncmt = cmt - 1; 
                    chkMresult = chkMselectVal("AP_APPROVER" + cmt + "");

                    //alert (cmt);
                    //alert (chkMresult);
                    if(cmt > 2){
                        if(chkMresult > 0){
                            nchkMresult = chkMselectVal("AP_APPROVER" + ncmt + "");

                            if(nchkMresult == 0){
                                ret = false;
                                break;
                            }else{
                                ret = true;
                            }
                        }
                    }else{
                        if(chkMresult > 0){
                            ret = true;
                        }else{
                            ret = false;
                        }                                
                    }
                }
        
        	if(ret ==false){
                alert('Please select an Approver for all the Levels selected or remove the Levels that are not required');
                return false;
            }
            else{
                //alert ();
                if (chkMselectVal('AP_APPROVER' + checkAppLevel + '') == 0){
                        alert ('Please select at least one Approver for each Approval Level added or delete the Approval Levels that are not required');
                        return false;
                }else{
                        return ret;
                }
            }
}
function changeAcronyms(fieldval){
	var arr = new Array();
    var selData = $('#' + fieldval).val();
    
    $('#' + fieldval).find('option').each(function() {
        //alert($(this).val() + '|' + $(this).text());
        arr.push($(this).val());
    });
    $('#' + fieldval).empty();
    //$('#' + fieldval).append($('<option>',{value: "", text: "Select One"}));
    
    $.each(arr, function( index, value ) {
      //alert( index + ": " + value );
      var chstr = value.split('');
      var ctext = '';
      for ( var i in chstr ) {
          //if(ctext != ''){
                ctext += chstr[i] + '.';
          //}else{
          //      ctext = chstr[i];
          //}
      }
      if (value != ''){
          if (selData == value){
            $('#' + fieldval).append('<option selected value=\"' + value + '\">' + ctext + '</option>');
          }else{
      		$('#' + fieldval).append('<option value=\"' + value + '\">' + ctext + '</option>');
          }
      }
    });
}
var objectToArray = function(obj) {
  var arr =[];
  for(let o in obj) {
    if (obj.hasOwnProperty(o)) {
      arr.push(obj[o]);
    }
  }
  return arr;
};

function openUserGuide() {
	window.open("custom/doc/WHRSC RDR User Guide.docx");
}
