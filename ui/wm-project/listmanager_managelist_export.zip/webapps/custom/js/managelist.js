var base_url = '/bizflowwebmaker/listmanager_AUT/';

var manageList = function(){
  $('#CONTAINER_EDIT').hide();
  $('#CONTAINER_VIEW').hide();

  if ($('#h_listId_view').val() != '') {
    $('#CONTAINER_VIEW').show();
    $('#container').hide();
    $('#CONTAINER_EDIT').hide();
    $('#VIEW_LIST_DESCRIPTION').attr({ readonly:'readonly', style:'width:813px; background-color:#efefef' });
    $('#VIEW_OWNING_ORG_CODE,#VIEW_LIST_NAME,#VIEW_LIST_EFF_START_DATE,#VIEW_LIST_EFF_END_DATE,#VIEW_ELIGIBILITY_DURATION_IN_DAYS')
      .attr({ readonly:'readonly', style:'background-color:#efefef' });

    $('#VIEW_LIST_EFF_START_DATE_calendar_anchor,#VIEW_LIST_EFF_END_DATE_calendar_anchor').addClass('hidden');
  }
  if ($('#h_listId').val() != '') {
    $('#CONTAINER_EDIT').show();
    $('#container').hide();
    $('#CONTAINER_VIEW').hide();
    $('#EDIT_OWNING_ORG_CODE,#EDIT_LIST_NAME').attr({ readonly:'readonly', style:'background-color:#efefef' });

    $('#h_currentUser_edit').val(opener.document.getElementById("h_currentUser").value);
  }

	$('#LIST_EFF_START_DATE_calendar_anchor').attr('tabindex', 95);
	$('#LIST_EFF_END_DATE_label_hint_container').attr('tabindex', 98);
    $('#LIST_EFF_END_DATE_calendar_anchor').attr('tabindex', 103);

	$('#LIST_TYPE').val('Priority Placement Program');
	$('#LISTNAMESEL').val('');

	$('#LISTMAMETEXT').addClass('hidden');
	$('#LISTMAMETEXT_label_container').addClass('hidden');

	$('#LISTMAMETEXT').on("change", function(){
		var listName = $('#LISTMAMETEXT').val();
		$.ajax({
			url: base_url + 'DuplicateListNameCheck.do?listName=' + listName,
			dataType: 'xml',
			cache: false,
			success: function (xmlResponse) {
				var data = $('record', xmlResponse ).map(function() {
					if($( 'COUNT', this ).text()!='0') {
						alert('List Name already exists, enter a different name');
						$('#LISTMAMETEXT').val('');
					}
				}).get();
			}
		});
	});

	$('#LISTNAMESEL').on("change", function(){
		var listName = $(this).children("option:selected").val();
		$.ajax({
			url: base_url + 'DuplicateListNameCheck.do?listName=' + listName,
			dataType: 'xml',
			cache: false,
			success: function (xmlResponse) {
				var data = $('record', xmlResponse ).map(function() {
					if($( 'COUNT', this ).text()!='0') {
						alert('List Name already exists, enter a different name');
						$('#LISTNAMESEL').val('');
					}
				}).get();
			}
		});

	});

	$('#LIST_TYPE').on("change", function(){
		var listType = '';
		var selVal = $(this).children("option:selected").val();
		if (selVal == 'Priority Placement Program') {
			listType = 'PPP';
			$('#LISTMAMETEXT').val('');
			$('#LISTNAMESEL').val('');
			$('#LISTMAMETEXT').addClass('hidden');
			$('#LISTMAMETEXT_label_container').addClass('hidden');
			$('#LISTNAMESEL').removeClass('hidden');
			$('#LISTNAMESEL_label_container').removeClass('hidden');

		}else {
			listType = 'PCP';
			$('#LISTMAMETEXT').val('');
			$('#LISTNAMESEL').val('');
			$('#LISTNAMESEL').addClass('hidden');
			$('#LISTNAMESEL_label_container').addClass('hidden');
			$('#LISTMAMETEXT').removeClass('hidden');
			$('#LISTMAMETEXT_label_container').removeClass('hidden');
		}
		$.ajax({
			url: base_url + 'ListOrgCodeDisplay.do?listType=' + listType,
			dataType: 'xml',
			cache: false,
			success: function (xmlResponse) {
				$('#OWNING_ORG_CODE').empty();
				if(listType=='PCP') {
					$('#OWNING_ORG_CODE').append('<option value= >Select One</option>');
				}
				var data = $('record', xmlResponse ).map(function() {
					 $('#OWNING_ORG_CODE').append('<option value=\"' + $( 'LOOKUP_CODE', this ).text() + '\">' + $( 'LOOKUP_CODE', this ).text() + '</option>');
				}).get();
			}
		});

	});

};

var  submitList = function(){
	var listTypeVal = $('#LIST_TYPE').val();
	if(listTypeVal=='Priority Placement Program') {
		$('#htypeName').val($('#LISTNAMESEL').val());
	}
	else {
		$('#htypeName').val($('#LISTMAMETEXT').val());
	}
	utility.greyOutScreen(true);
};

var callMain = function(){
	$('#LIST_TYPE').val('Priority Placement Program');
	$('#LISTNAMESEL').val('');
	$('#LISTMAMETEXT').val('');
	$('#LISTNAMESEL').removeClass('hidden');
	$('#LISTNAMESEL_label_container').removeClass('hidden');
	$('#LISTMAMETEXT').addClass('hidden');
	$('#LISTMAMETEXT_label_container').addClass('hidden');

	$('#PRIORITY').val('');
	$('#LIST_DESCRIPTION').val('');
	$('#LIST_EFF_START_DATE').val('');
	$('#LIST_EFF_END_DATE').val('');
	$('#ELIGIBILITY_DURATION_IN_DAYS').val('');

	$.ajax({
		url: base_url + 'ListOrgCodeDisplay.do?listType=' + 'PPP',
		dataType: 'xml',
		cache: false,
		success: function (xmlResponse) {
			$('#OWNING_ORG_CODE').empty();
			var data = $('record', xmlResponse ).map(function() {
				 $('#OWNING_ORG_CODE').append('<option value=\"' + $( 'LOOKUP_CODE', this ).text() + '\">' + $( 'LOOKUP_CODE', this ).text() + '</option>');
			}).get();
		}
	});
};

var mandatoryValues = function(){
  var isFull = false;
  if ( $('#EDIT_LIST_EFF_START_DATE').val() != ''
        && $('#EDIT_ELIGIBILITY_DURATION_IN_DAYS').val() != ''
      ) {
    isFull = true;
  } else {
    alert('Please complete Mandatory Fields');
  }
  return isFull;
};

var checkIfUpdated = function(){
  if ($('#h_wasUpdated').val() == '1')
    return true;
  else
    return false;
};
var refreshLists = function(){
  alert ('List Successfully updated');
  opener.parent.location.reload();

};
var closeWindow = function(){
  window.close();
};
