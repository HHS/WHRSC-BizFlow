var base_url = '/bizflowwebmaker/whrsc_AUT/';
var base_branch_url = '/bizflowwebmaker/whrsc_branchAUT/';
var isRunBranchInfo = "false";

var appointTransInfo = function(){

	//check manual initiation
	var  from = $('#pv_from').val();
	if(from=='Appointment' || from=='Determine Staffing Process')
	{
		var isInitialLoad = $('#pv_initialLoad').val();
		if(isInitialLoad=="false")
		{
			$('#ACTION_TYPE').val($('#pv_actionType').val());

					// Request Date
			var dateReceivedStr = $('#pv_date_received').val();
			if (dateReceivedStr != null && dateReceivedStr.length > 0) {
				var dateReceived = new Date(dateReceivedStr);  // dateReceivedStr is GMT
				var newDate = new Date(dateReceived.getTime() - dateReceived.getTimezoneOffset() * 60000); // Adjust to local time
				var dateReceivedLabel = utility.getDateString({isUTC: false, dateFormat: 'mm/dd/yyyy'}, newDate);
				$('#DATE_RECEIVED').val(dateReceivedLabel);
				$('#DATE_SF52_RECEIVED').val(dateReceivedLabel);
			}
			$('#HR_SPECIALIST_ID').val($('#h_currentUserMemberID').val());

			$('#pv_initialLoad').val("true");
		}
	}

    //508 setup
	/*  remove dot related script
    $('#ADMIN_CODE_D').val(addComma($('#ADMIN_CODE').val()));
    $('#ADMIN_CODE').val($('#ADMIN_CODE').val().replace(/\./g,''));//Temp
    $('#INSTITUTE_D').val(addComma($('#INSTITUTE').val()));
    $('#INSTITUTE').val($('#INSTITUTE').val().replace(/\./g,''));//Temp
    */

    $('#HR_LLN_INPUT_label').attr('title', 'Asterisk denotes a required field');
    $('#HR_LLN_INPUT_F_label').attr('title', 'Asterisk denotes a required field');
    $('#HR_LLN_INPUT_E_label').attr('title', 'Asterisk denotes a required field');
    $('#GLOBAL_RECRUITMENT_label').attr('title', 'Asterisk denotes a required field');
    //$('#DATE_SF52_RECEIVED_label').attr('title', 'Asterisk denotes a required field');
    $('#DATE_SF52_RECEIVED_label').attr('title', 'mm/dd/yyyy');
    /*  remove dot related script
	$('#ADMIN_CODE_D_label').attr('title', 'Asterisk denotes a required field');
	$('#INSTITUTE_D_label').attr('title', 'Asterisk denotes a required field');
	*/
    $('#ADMIN_CODE_label').attr('title', 'Asterisk denotes a required field');
    $('#INSTITUTE_label').attr('title', 'Asterisk denotes a required field');
    //$('#PROPOSED_EFF_DATE_label').attr('title', 'Asterisk denotes a required field');
    $('#PROPOSED_EFF_DATE_label').attr('title', 'mm/dd/yyyy');
    $('#BRANCH_CHIEF_ID_label').attr('title', 'Asterisk denotes a required field');
    $('#TEAM_LEADER_ID_label').attr('title', 'Asterisk denotes a required field');
    $('#HR_SENIOR_ADVISOR_ID_label').attr('title', 'Asterisk denotes a required field');
    $('#HR_SPECIALIST_ID_label').attr('title', 'Asterisk denotes a required field');
    $('#HR_ASSISTANT_ID_label').attr('title', 'Asterisk denotes a required field');
    $('#HR_SPA_ID_label').attr('title', 'Asterisk denotes a required field');
    $('#PCKG_COMPLETE_label').attr('title', 'Asterisk denotes a required field');
    $('#PRIORITY_label').attr('title', 'Asterisk denotes a required field');
    $('#RYB_CODE_label').attr('title', 'Asterisk denotes a required field');
    $('#RYB_STATUS_label').attr('title', 'Asterisk denotes a required field');
    $('#RYB_DESCRIPTION_label').attr('title', 'Asterisk denotes a required field');
    $('#MISSING_DOCS_RECEIPT_DATE_label').attr('title', 'mm/dd/yyyy');

		$('#RYB_CODE').addClass('hidden');

    $('#HR_LLN_INPUT_E_container').addClass('hidden');
	$('#HR_LLN_INPUT_E').attr('_required', 'false');

    $('#HR_LLN_INPUT_F_container').addClass('hidden');
	$('#HR_LLN_INPUT_F').attr('_required', 'false');

    WHRSCMain.setAlwaysReadonly('ACTION_TYPE');
    $('#ACTION_TYPE').css('background-color', '#efefef');

	$('#DATE_SF52_RECEIVED_calendar_anchor').attr('tabindex', 71);
    $('#PROPOSED_EFF_DATE_calendar_anchor').attr('tabindex', 101);
    $('#MISSING_DOCS_EMAIL_SENT_DATE_calendar_anchor').attr('tabindex', 171);
    $('#MISSING_DOCS_RECEIPT_DATE_calendar_anchor').attr('tabindex', 181);

    WHRSCMain.setAlwaysReadonly('DATE_RECEIVED');
    $('#DATE_RECEIVED').css('background-color', '#efefef');
    $('#DATE_RECEIVED_calendar_anchor').addClass('hidden');
	
	WHRSCMain.setAlwaysReadonly('PROPOSED_EFF_DATE');
    $('#PROPOSED_EFF_DATE').css('background-color', '#efefef');
    $('#PROPOSED_EFF_DATE_calendar_anchor').addClass('hidden');

	if(from!='Appointment') {
    	/* remove dot related script
		WHRSCMain.setAlwaysReadonly('INSTITUTE_D');
		$('#INSTITUTE_D').css('background-color', '#efefef');
        $('#INSTITUTE_container').addClass('hidden');
        $('#INSTITUTE_label_container').addClass('hidden');
		WHRSCMain.setAlwaysReadonly('ADMIN_CODE_D');
		$('#ADMIN_CODE_D').css('background-color', '#efefef');
        $('#ADMIN_CODE_container').addClass('hidden');
        $('#ADMIN_CODE_label_container').addClass('hidden');
		*/
		WHRSCMain.setAlwaysReadonly('INSTITUTE');
		$('#INSTITUTE').css('background-color', '#efefef');
        WHRSCMain.setAlwaysReadonly('ORG_INITS');
		WHRSCMain.setAlwaysReadonly('ADMIN_CODE');
		$('#ADMIN_CODE').css('background-color', '#efefef');
		$('#ORG_INITS').css('background-color', '#efefef');

	}else{
		WHRSCMain.setAlwaysReadonly('INSTITUTE');
		$('#INSTITUTE').css('background-color', '#efefef');
        WHRSCMain.setAlwaysReadonly('ORG_INITS');
		$('#ORG_INITS').css('background-color', '#efefef');
		/* remove dot related script
    	$('#INSTITUTE_D_container').addClass('hidden');
        $('#INSTITUTE_D_label_container').addClass('hidden');

        $('#ADMIN_CODE_D_container').addClass('hidden');
        $('#ADMIN_CODE_D_label_container').addClass('hidden');
		*/


		if($('#h_reqAdminEditable').val()=='no') {
			WHRSCMain.setAlwaysReadonly('ADMIN_CODE');
			$('#ADMIN_CODE').css('background-color', '#efefef');

		}
		else {
			setAdminAutoComplete();
			var requestNumber = $('#pv_requistionNumber').val();
			var usasResult = $('#husasResult').val();
			if (requestNumber != '' && usasResult=="true")  {
				//var requisitionNumber = '';
				//var positionTitle= '';
				//var payPlan= '';
				//var series= '';
				//var grade= '';
				var effDate= '';
				var orgInits= '';
				var customer= '';
				var branch= '';
				var adminCode= '';

				$.ajax({
					url: base_url + 'searchReqNumber.do?searchRequestNumber=' + requestNumber,
					dataType: 'xml',
					cache: false,
					async: false,
					success: function (xmlResponse) {
						var data = $('record', xmlResponse ).map(function() {
							//requisitionNumber = $( 'ID', this ).text();
							//positionTitle = $( 'JOB_TITLE', this ).text();
							//payPlan = $( 'PAY_PLAN', this ).text();
							//series = $( 'OCC_SERIES', this ).text();
							//grade = $( 'GRADE', this ).text();
							effDate = $( 'EFF_DATE', this ).text();
							orgInits = $( 'ORG_INITS', this ).text();
							customer = $( 'IC', this ).text();
							branch =  $( 'BRANCH', this ).text();
							adminCode = $( 'ADMIN_CODE', this ).text();
						}).get();
					}
				});
				var proposedEffDateLabel = "";
				var effDateString = effDate;
				if (effDateString != null && effDateString.length > 0) {
					var proposedEffDate = new Date(effDateString);
					proposedEffDateLabel = utility.getDateString({isUTC: false, dateFormat: 'mm/dd/yyyy'}, proposedEffDate);
				}

				//$('#pv_positionTitle').val(positionTitle);
				//$('#pv_payPlan').val(payPlan);
				//$('#pv_series').val(series);
				//$('#pv_grade').val(grade);
				$('#PROPOSED_EFF_DATE').val(proposedEffDateLabel);
				$('#ORG_INITS').val(orgInits);
				$('#INSTITUTE').val(customer);
				$('#ADMIN_CODE').val(adminCode);
				$('#pv_branch').val(branch);
				$('#pv_originalBranch').val(branch);

				//$('#PRERECRUIT_COMMENTS').val(preComment);
				//$('#CAN_NO').val(canNumber);
				//$('#DATE_JOB_OPENING_APPROVED').val(dateJobReqAppLabel);
				isRunBranchInfo = "true";
				getbranchInfo();
			}
		}
    }


    //$('#ADMIN_CODE').attr('_type', 'text');
	/* remove dot related script
	$('#INSTITUTE_D').attr('_type', 'text');
	*/


    $('#INSTITUTE').attr('_type', 'text');
	$('#ORG_INITS').attr('_type', 'text');
	$('#MISSING_DOCS').attr('_type', 'string');
	$('#COMMENTS_STATUS').attr('_type', 'string');

    //if ($('#PCKG_COMPLETE').val() == 'No'){
        WHRSCMain.setAlwaysReadonly('MISSING_DOCS_EMAIL_SENT_DATE');
        $('#MISSING_DOCS_EMAIL_SENT_DATE').css('background-color', '#efefef');
        $('#MISSING_DOCS_EMAIL_SENT_DATE_calendar_anchor').addClass('hidden');
    //}


    /*$('#PCKG_COMPLETE').on("change", function(){
        var comSelVal = $(this).children("option:selected").val();
        if (comSelVal == 'Yes') {

            $('#MISSING_DOCS_EMAIL_SENT_DATE').removeAttr("readonly");
            $('#MISSING_DOCS_EMAIL_SENT_DATE').css('background-color', '#FFFFFF');
            $('#MISSING_DOCS_EMAIL_SENT_DATE_calendar_anchor').removeClass('hidden');


        }else{

            WHRSCMain.setAlwaysReadonly('MISSING_DOCS_EMAIL_SENT_DATE');
            $('#MISSING_DOCS_EMAIL_SENT_DATE').css('background-color', '#efefef');
            $('#MISSING_DOCS_EMAIL_SENT_DATE_calendar_anchor').addClass('hidden');
            $('#MISSING_DOCS_EMAIL_SENT_DATE').val('');
        }
    });*/

    if ($('#GLOBAL_RECRUITMENT').val() == 'No'){

        $('#tl_group').addClass('hidden');
        $('#O_STL').val('');
    }


 /*
    $('#GLOBAL_RECRUITMENT').on("change", function(){
        var comSelVal = $(this).children("option:selected").val();
        if (comSelVal == 'Yes') {

            $('#tl_group').removeClass('hidden');


        }else{

            $('#tl_group').addClass('hidden');
        	$('#O_STL').val('');
        }

    });
*/

	if(isRunBranchInfo=="false") {
		getbranchInfo();
	}



	$('#GLOBAL_RECRUITMENT').on("change", function(){
		var selVal = $(this).children("option:selected").val();

		if (selVal == 'Yes') {
			 $('#tl_group').removeClass('hidden');
			$('#pv_branch').val("SSB");

			$('#HR_SPECIALIST_ID').text('');
			$('#h_hrSpecialistUName').val('');
			$('#h_hrSpecialistName').val('');
			$('#h_hrSpecialist').val('');
			$('#h_hrSpecialistEmail').val('');

			$('#BRANCH_CHIEF_ID').text('');
			$('#h_branchChiefUName').val('');
			$('#h_branchChiefName').val('');
			$('#h_branchChief').val('');
			$('#h_branchChiefEmail').val('');

			$('#TEAM_LEADER_ID').text('');
			$('#h_teamLeaderUName').val('');
			$('#h_teamLeaderName').val('');
			$('#h_teamLeader').val('');
			$('#h_teamLeaderEmail').val('');

			$('#HR_SENIOR_ADVISOR_ID').text('');
			$('#h_hrSeniorAdvisorUName').val('');
			$('#h_hrSeniorAdvisorName').val('');
			$('#h_hrSeniorAdvisor').val('');
			$('#h_hrSeniorAdvisorEmail').val('');

			$.ajax({
				url: base_branch_url + 'getBranchHS.do?branchhs=' + "/WHRSC/Role Specific/HR Specialist/SSB",
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#HR_SPECIALIST_ID').empty();
					$('#HR_SPECIALIST_ID').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#HR_SPECIALIST_ID').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();

				}
			});
			$.ajax({
				url: base_branch_url + 'getBranchBC.do?branchbc=' + "/WHRSC/Role Specific/Branch Chief/SSB",
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#BRANCH_CHIEF_ID').empty();
					$('#BRANCH_CHIEF_ID').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#BRANCH_CHIEF_ID').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();

				}
			});
			$.ajax({
				url: base_branch_url + 'getBranchTL.do?branchtl=' + "/WHRSC/Role Specific/HR Team Leader/SSB",
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#TEAM_LEADER_ID').empty();
					$('#TEAM_LEADER_ID').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#TEAM_LEADER_ID').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();

				}
			});
			$.ajax({
				url: base_branch_url + 'getBranchSA.do?branchsa=' +  "/WHRSC/Role Specific/HR Senior Advisor/SSB",
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#HR_SENIOR_ADVISOR_ID').empty();
					$('#HR_SENIOR_ADVISOR_ID').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#HR_SENIOR_ADVISOR_ID').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();

				}
			});

		}else {

			$('#HR_SPECIALIST_ID').text('');
			$('#h_hrSpecialistUName').val('');
			$('#h_hrSpecialistName').val('');
			$('#h_hrSpecialist').val('');
			$('#h_hrSpecialistEmail').val('');

			$('#BRANCH_CHIEF_ID').text('');
			$('#h_branchChiefUName').val('');
			$('#h_branchChiefName').val('');
			$('#h_branchChief').val('');
			$('#h_branchChiefEmail').val('');

			$('#TEAM_LEADER_ID').text('');
			$('#h_teamLeaderUName').val('');
			$('#h_teamLeaderName').val('');
			$('#h_teamLeader').val('');
			$('#h_teamLeaderEmail').val('');

			$('#HR_SENIOR_ADVISOR_ID').text('');
			$('#h_hrSeniorAdvisorUName').val('');
			$('#h_hrSeniorAdvisorName').val('');
			$('#h_hrSeniorAdvisor').val('');
			$('#h_hrSeniorAdvisorEmail').val('');

		    $('#tl_group').addClass('hidden');
        	$('#O_STL').val('');

			//var orgBranch = $('#h_originalBranch').val();
			//$('#h_branch').val(orgBranch);
			var orgBranch = $('#pv_originalBranch').val();
			$('#pv_branch').val(orgBranch);

			$.ajax({
				url: base_branch_url + 'getBranchHS.do?branchhs=' + '/WHRSC/Role Specific/HR Specialist/' + orgBranch,
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#HR_SPECIALIST_ID').empty();
					$('#HR_SPECIALIST_ID').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#HR_SPECIALIST_ID').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();

				}
			});
			$.ajax({
				url: base_branch_url + 'getBranchBC.do?branchbc=' + '/WHRSC/Role Specific/Branch Chief/' + orgBranch,
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#BRANCH_CHIEF_ID').empty();
					$('#BRANCH_CHIEF_ID').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#BRANCH_CHIEF_ID').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();

				}
			});
			$.ajax({
				url: base_branch_url + 'getBranchTL.do?branchtl=' + '/WHRSC/Role Specific/HR Team Leader/' + orgBranch,
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#TEAM_LEADER_ID').empty();
					$('#TEAM_LEADER_ID').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#TEAM_LEADER_ID').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();

				}
			});
			$.ajax({
				url: base_branch_url + 'getBranchSA.do?branchsa=' +  '/WHRSC/Role Specific/HR Senior Advisor/' + orgBranch,
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					$('#HR_SENIOR_ADVISOR_ID').empty();
					$('#HR_SENIOR_ADVISOR_ID').append('<option value= >Select One</option>');
					var data = $('record', xmlResponse ).map(function() {
						 $('#HR_SENIOR_ADVISOR_ID').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
					}).get();

				}
			});
		}
	});

	 $('#MISSING_DOCS_RECEIPT_DATE').on("change", function(){
		 var dcpr = $('#MISSING_DOCS_RECEIPT_DATE').val();
        $('#DATE_NEED_VALIDATED').val(dcpr);
    });



	$('#BRANCH_CHIEF_ID').on('change', function() {
		var val = $('#BRANCH_CHIEF_ID option:selected').val();
		if(val !='') {
			var uName = $('#BRANCH_CHIEF_ID option:selected').text();
			var fullName = utility.getFirstLastName(uName);
			$('#h_branchChiefUName').val(uName);
			$('#h_branchChiefName').val(fullName);
			$('#h_branchChief').val('[U]'+ val);

			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#BRANCH_CHIEF_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_branchChiefEmail').val($( 'EMAIL', this ).text());
					}).get();

				}
			});
		}
		else {
			$('#h_branchChiefUName').val('');
			$('#h_branchChiefName').val('');
			$('#h_branchChief').val('');
			$('#h_branchChiefEmail').val('');
		}

	});



	$('#TEAM_LEADER_ID').on('change', function() {
		var val = $('#TEAM_LEADER_ID option:selected').val();
		if(val !='') {
			var uName = $('#TEAM_LEADER_ID option:selected').text();
			var fullName = utility.getFirstLastName(uName);
			$('#h_teamLeaderUName').val(uName);
			$('#h_teamLeaderName').val(fullName);
			$('#h_teamLeader').val('[U]'+ val);

			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#TEAM_LEADER_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_teamLeaderEmail').val($( 'EMAIL', this ).text());
					}).get();

				}
			});
		}
		else {
			$('#h_teamLeaderUName').val('');
			$('#h_teamLeaderName').val('');
			$('#h_teamLeader').val('');
			$('#h_teamLeaderEmail').val('');
		}

	});



	$('#HR_SENIOR_ADVISOR_ID').on('change', function() {
		var val = $('#HR_SENIOR_ADVISOR_ID option:selected').val();
		if(val !='') {
			var uName = $('#HR_SENIOR_ADVISOR_ID option:selected').text();
			var fullName = utility.getFirstLastName(uName);
			$('#h_hrSeniorAdvisorUName').val(uName);
			$('#h_hrSeniorAdvisorName').val(fullName);
			$('#h_hrSeniorAdvisor').val('[U]'+ val);

			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#HR_SENIOR_ADVISOR_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSeniorAdvisorEmail').val($( 'EMAIL', this ).text());
					}).get();

				}
			});
		}
		else {
			$('#h_hrSeniorAdvisorUName').val('');
			$('#h_hrSeniorAdvisorName').val('');
			$('#h_hrSeniorAdvisor').val('');
			$('#h_hrSeniorAdvisorEmail').val('');
		}

	});




	$('#HR_SPECIALIST_ID').on('change', function() {
		var val = $('#HR_SPECIALIST_ID option:selected').val();
		if(val !='') {
			var uName = $('#HR_SPECIALIST_ID option:selected').text();
			var fullName = utility.getFirstLastName(uName);
			$('#h_hrSpecialistUName').val(uName);
			//$('#test').val('tester');
			$('#h_hrSpecialistName').val(fullName);
			$('#h_hrSpecialist').val('[U]'+ val);
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#HR_SPECIALIST_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSpecialistEmail').val($( 'EMAIL', this ).text());
					}).get();

				}
			});
		}
		else {
			$('#h_hrSpecialistUName').val('');
			$('#h_hrSpecialistName').val('');
			$('#h_hrSpecialist').val('');
			$('#h_hrSpecialistEmail').val('');
		}

	});


	var assistVal = $('#HR_ASSISTANT_ID option:selected').val();
	if(assistVal !='') {
		var uName = $('#HR_ASSISTANT_ID option:selected').text();
		var fullName = utility.getFirstLastName(uName);
		$('#h_hrAssistantUName').val(uName);
		$('#h_hrAssistantName').val(fullName);
		$('#h_hrAssistant').val('[U]'+ assistVal);
		if($('#h_hrAssistantEmail').val()=='') {
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#HR_ASSISTANT_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrAssistantEmail').val($( 'EMAIL', this ).text());
					}).get();

				}
			});
		}
	}
	else {
		$('#h_hrAssistantUName').val('');
		$('#h_hrAssistantName').val('');
		$('#h_hrAssistant').val('');
		$('#h_hrAssistantEmail').val('');
	}

	$('#HR_ASSISTANT_ID').on('change', function() {
		var val = $('#HR_ASSISTANT_ID option:selected').val();
		if(val !='') {
			var uName = $('#HR_ASSISTANT_ID option:selected').text();
			var fullName = utility.getFirstLastName(uName);
			$('#h_hrAssistantUName').val(uName);
			$('#h_hrAssistantName').val(fullName);
			$('#h_hrAssistant').val('[U]'+ val);
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#HR_ASSISTANT_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrAssistantEmail').val($( 'EMAIL', this ).text());
					}).get();

				}
			});
		}
		else {
			$('#h_hrAssistantUName').val('');
			$('#h_hrAssistantName').val('');
			$('#h_hrAssistant').val('');
			$('#h_hrAssistantEmail').val('');
		}

	});

	var faVal = $('#HR_SPA_ID option:selected').val();
	if(faVal !='') {
		var uName = $('#HR_SPA_ID option:selected').text();
		var fullName = utility.getFirstLastName(uName);
		$('#h_hrSpaUName').val(uName);
		$('#h_hrSpaName').val(fullName);
		$('#h_hrSpa').val('[U]'+ faVal);
		if($('#h_hrSpaEmail').val()=='') {
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#HR_SPA_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSpaEmail').val($( 'EMAIL', this ).text());
					}).get();

				}
			});
		}
	}
	else {
		$('#h_hrSpaUName').val('');
		$('#h_hrSpaName').val('');
		$('#h_hrSpa').val('');
		$('#h_hrSpaEmail').val('');
	}

	$('#HR_SPA_ID').on('change', function() {
		var val = $('#HR_SPA_ID option:selected').val();
		if(val !='') {
			var uName = $('#HR_SPA_ID option:selected').text();
			var fullName = utility.getFirstLastName(uName);
			$('#h_hrSpaUName').val(uName);
			$('#h_hrSpaName').val(fullName);
			$('#h_hrSpa').val('[U]'+ val);
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#HR_SPA_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSpaEmail').val($( 'EMAIL', this ).text());
					}).get();

				}
			});
		}
		else {
			$('#h_hrSpaUName').val('');
			$('#h_hrSpaName').val('');
			$('#h_hrSpa').val('');
			$('#h_hrSpaEmail').val('');
		}

	});




	setACAutoComplete();

    if ($('#h_lastname').val() != '') {

        	var li_last_name = "<li id=\"" + $('#h_lastname').val() + "\" ><b>";
			li_last_name += removefunc.getAutoCompRemoveIconElement($('#h_lastname').val(), $('#h_lastname').val(), '51');
            li_last_name += $('#h_lastname').val() + '</b></li>';

            var li_first_name = "<li id=\"" + $('#h_firstname').val() + "\" ><b>";
			li_first_name += removefunc.getAutoCompRemoveIconElement($('#h_firstname').val(), $('#h_firstname').val(), '52');
            li_first_name += $('#h_firstname').val() + '</b></li>';

            var li_email = "<li id=\"" + $('#h_email').val() + "\" ><b>";
			li_email += removefunc.getAutoCompRemoveIconElement($('#h_email').val(), $('#h_email').val(), '53');
			li_email += $('#h_email').val() + '</b></li>';


		/*var li_org_name = "<li id=\"" + $("#AC_ADMIN_CD").val() + "_dscr\">";
		var li_admin_cd = "<li id=\"" + $("#AC_ADMIN_CD").val() + "\">";
		if ($('#h_readOnly').val() != 'y') {
			li_org_name += utility.getAutoCompRemoveIconElement($('#AC_ADMIN_CD').val() + '_dscr', $('#AC_ADMIN_CD_DESCR').val(), '35');
			li_admin_cd += utility.getAutoCompRemoveIconElement($('#AC_ADMIN_CD').val(), $('#AC_ADMIN_CD').val(), '25');
		}
		li_admin_cd += $('#AC_ADMIN_CD').val() + '</li>';
		li_org_name += $('#AC_ADMIN_CD_DESCR').val() + '</li>';*/

        $('#HR_LLN_DISP').append(li_last_name).removeClass('hidden');
        $('#HR_LLN_DISP_F').append(li_first_name).removeClass('hidden');
        $('#HR_LLN_DISP_E').append(li_email).removeClass('hidden');

        $('#HR_LLN_INPUT_container').addClass('hidden');
		$('#HR_LLN_INPUT').attr('_required', 'false');
	}else{
    	$('#HR_LLN_section_8').addClass('hidden');
    }

    $('#HR_LLN_DISP').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#HR_LLN_DISP').addClass('hidden').empty();
            $('#HR_LLN_DISP_F').addClass('hidden').empty();
            $('#HR_LLN_DISP_E').addClass('hidden').empty();
			$('#HR_LLN_INPUT_container').removeClass('hidden');
			$('#HR_LLN_INPUT').attr('_required', 'true');
            $('#HR_LLN_section_8').addClass('hidden');
            $('#h_lastname').val('');
            $('#h_firstname').val('');
            $('#h_email').val('');
		}
	});

    $('#HR_LLN_DISP_F').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#HR_LLN_DISP_F').addClass('hidden').empty();
            $('#HR_LLN_DISP').addClass('hidden').empty();
            $('#HR_LLN_DISP_E').addClass('hidden').empty();
			$('#HR_LLN_INPUT_container').removeClass('hidden');
			$('#HR_LLN_INPUT').attr('_required', 'true');
            $('#HR_LLN_section_8').addClass('hidden');
            $('#h_lastname').val('');
            $('#h_firstname').val('');
            $('#h_email').val('');
		}
	});

	$('#HR_LLN_DISP_E').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#HR_LLN_DISP_E').addClass('hidden').empty();
            $('#HR_LLN_DISP').addClass('hidden').empty();
            $('#HR_LLN_DISP_F').addClass('hidden').empty();
			$('#HR_LLN_INPUT_container').removeClass('hidden');
			$('#HR_LLN_INPUT').attr('_required', 'true');
            $('#HR_LLN_section_8').addClass('hidden');
            $('#h_lastname').val('');
            $('#h_firstname').val('');
            $('#h_email').val('');
		}
	});

}

var getbranchInfo = function () {
	var branchName = $('#pv_branch').val();
	var selVal = $('#GLOBAL_RECRUITMENT').val();
	if (selVal == 'Yes') {
		$('#pv_branch').val('SSB');
		branchName = 'SSB';
	}
	var bcUgPath = '/WHRSC/Role Specific/Branch Chief/' + branchName;
	var tlUgPath = '/WHRSC/Role Specific/HR Team Leader/' + branchName;
	var saUgPath = '/WHRSC/Role Specific/HR Senior Advisor/' + branchName;
	var hsUgPath = '/WHRSC/Role Specific/HR Specialist/' + branchName;

	$.ajax({
		url: base_branch_url + 'getBranchHS.do?branchhs=' + hsUgPath,
		dataType: 'xml',
		cache: false,
		async: false,
		success: function (xmlResponse) {
			$('#HR_SPECIALIST_ID').empty();
			$('#HR_SPECIALIST_ID').append('<option value= >Select One</option>');
			var data = $('record', xmlResponse ).map(function() {
				 $('#HR_SPECIALIST_ID').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
				 //if (hs_id !== undefined && hs_id !== '') {
				//	$('#HR_SPECIALIST_ID').val(hs_id);
				// }
			}).get();

		}
	});
	var hs_id = $('#hs_id').val();
	var hs_name = $('#hs_name').val();

	if (hs_id !== undefined && hs_id !== '') {
		$('#HR_SPECIALIST_ID').val(hs_id);
		$('#HR_SPECIALIST_ID option:selected').text(hs_name);
		var fullName = utility.getFirstLastName(hs_name);
		$('#h_hrSpecialistUName').val(hs_name);
		$('#h_hrSpecialistName').val(fullName);
		$('#h_hrSpecialist').val('[U]'+ hs_id);
		if($('#h_hrSpecialistEmail').val()=='') {
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#HR_SPECIALIST_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSpecialistEmail').val($( 'EMAIL', this ).text());
					}).get();

				}
			});
		}
	}

	else {
		$('#HR_SPECIALIST_ID option:selected').val('');
		$('#HR_SPECIALIST_ID option:selected').text('Select One');
		$('#h_hrSpecialistUName').val('');
		$('#h_hrSpecialistName').val('');
		$('#h_hrSpecialist').val('');
		$('#h_hrSpecialistEmail').val('');
	}

	$.ajax({
		url: base_branch_url + 'getBranchBC.do?branchbc=' + bcUgPath,
		dataType: 'xml',
		cache: false,
		async: false,
		success: function (xmlResponse) {
			$('#BRANCH_CHIEF_ID').empty();
			$('#BRANCH_CHIEF_ID').append('<option value= >Select One</option>');
			var data = $('record', xmlResponse ).map(function() {
				 $('#BRANCH_CHIEF_ID').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
				// if (bc_id !== undefined && bc_id !== '') {
				//	$('#BRANCH_CHIEF_ID').val(bc_id);
				// }
			}).get();

		}
	});
	var bc_id = $('#bc_id').val();
	var bc_name = $('#bc_name').val();
	if (bc_id !== undefined && bc_id !== '') {
		$('#BRANCH_CHIEF_ID').val(bc_id);
		$('#BRANCH_CHIEF_ID option:selected').text(bc_name);
		var fullName = utility.getFirstLastName(bc_name);
		$('#h_branchChiefUName').val(bc_name);
		$('#h_branchChiefName').val(fullName);
		$('#h_branchChief').val('[U]'+ bc_id);
		if($('#h_branchChiefEmail').val()=='') {
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#BRANCH_CHIEF_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_branchChiefEmail').val($( 'EMAIL', this ).text());
					}).get();

				}
			});
		}

	 }
	else {
		$('#BRANCH_CHIEF_ID').val('');
		$('#BRANCH_CHIEF_ID option:selected').text('Select One');
		$('#h_branchChiefUName').val('');
		$('#h_branchChiefName').val('');
		$('#h_branchChief').val('');
		$('#h_branchChiefEmail').val('');
	}

	$.ajax({
		url: base_branch_url + 'getBranchTL.do?branchtl=' + tlUgPath,
		dataType: 'xml',
		cache: false,
		async: false,
		success: function (xmlResponse) {
			$('#TEAM_LEADER_ID').empty();
			$('#TEAM_LEADER_ID').append('<option value= >Select One</option>');
			var data = $('record', xmlResponse ).map(function() {
				 $('#TEAM_LEADER_ID').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
				// if (tl_id !== undefined && tl_id !== '') {
				//	$('#TEAM_LEADER_ID').val(tl_id);
				// }
			}).get();

		}
	});
	var tl_id = $('#tl_id').val();
	var tl_name = $('#tl_name').val();
	if (tl_id !== undefined && tl_id !== '') {
		$('#TEAM_LEADER_ID').val(tl_id);
		$('#TEAM_LEADER_ID option:selected').text(tl_name);
		var fullName = utility.getFirstLastName(tl_name);
		$('#h_teamLeaderUName').val(tl_name);
		$('#h_teamLeaderName').val(fullName);
		$('#h_teamLeader').val('[U]'+ tl_id);
		if($('#h_teamLeaderEmail').val()=='') {
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#TEAM_LEADER_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_teamLeaderEmail').val($( 'EMAIL', this ).text());
					}).get();

				}
			});
		}

	 }
	else {
		$('#TEAM_LEADER_ID').val('');
		$('#TEAM_LEADER_ID option:selected').text('Select One');
		$('#h_teamLeaderUName').val('');
		$('#h_teamLeaderName').val('');
		$('#h_teamLeader').val('');
		$('#h_teamLeaderEmail').val('');
	}

	$.ajax({
		url: base_branch_url + 'getBranchSA.do?branchsa=' + saUgPath,
		dataType: 'xml',
		cache: false,
		async: false,
		success: function (xmlResponse) {
			$('#HR_SENIOR_ADVISOR_ID').empty();
			$('#HR_SENIOR_ADVISOR_ID').append('<option value= >Select One</option>');
			var data = $('record', xmlResponse ).map(function() {
				 $('#HR_SENIOR_ADVISOR_ID').append('<option value=\"' + $( 'MEMBERID', this ).text() + '\">' + $( 'NAME', this ).text() + '</option>');
				// if (sa_id !== undefined && sa_id !== '') {
				//	$('#HR_SENIOR_ADVISOR_ID').val(sa_id);
				// }
			}).get();

		}
	});
	var sa_id = $('#sa_id').val();
	var sa_name = $('#sa_name').val();
	if (sa_id !== undefined && sa_id !== '') {
		$('#HR_SENIOR_ADVISOR_ID').val(sa_id);
		$('#HR_SENIOR_ADVISOR_ID option:selected').text(sa_name);
		var fullName = utility.getFirstLastName(sa_name);
		$('#h_hrSeniorAdvisorUName').val(sa_name);
		$('#h_hrSeniorAdvisorName').val(fullName);
		$('#h_hrSeniorAdvisor').val('[U]'+ sa_id);
		if($('#h_hrSeniorAdvisorEmail').val()=='') {
			$.ajax({
				url: base_url + 'getUserEmail.do?memberID=' + $('#HR_SENIOR_ADVISOR_ID').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						$('#h_hrSeniorAdvisorEmail').val($( 'EMAIL', this ).text());
					}).get();

				}
			});
		}
	 }
	 else {
		$('#HR_SENIOR_ADVISOR_ID').val('');
		$('#HR_SENIOR_ADVISOR_ID option:selected').text('Select One');
		$('#h_hrSeniorAdvisorUName').val('');
		$('#h_hrSeniorAdvisorName').val('');
		$('#h_hrSeniorAdvisor').val('');
		$('#h_hrSeniorAdvisorEmail').val('');
	}

}

//added to handle manual initation admin code
var setAdminAutoComplete = function () {

	$('#ADMIN_CODE').autocomplete({
		source: function (request, response) {
			$.ajax({
				url: base_url + 'SearchAdminCode.do?searchAdminCode=' + $('#ADMIN_CODE').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {


						return {
							customer: $( 'IC', this ).text(),
							branch: 'Branch ' + $( 'BRANCH', this ).text(),
							adminCode: $( 'ADMIN_CODE', this ).text(),
							adminTitle: $( 'ADMIN_TITLE', this ).text(),
							orgInits: $( 'ORG_INITS', this ).text()
						};
					}).get();
					response(data);
				}
			})
		},
		minLength: 2,
		change: function (e, u) {
			//If the No match found" u.item will return null, clear the TextBox.
			if (u.item == null) {
				//Clear the AutoComplete TextBox.
				var pos = $(this).position();
				$('#ADMIN_CODE_noMatch').remove();
				$(this).after("<span id='ADMIN_CODE_noMatch' class='acNoMatch'>Invalid Selection:<br />Item must be selected from the available options.</span>");
				$('#ADMIN_CODE_noMatch').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
				setTimeout(function() {
					$('#ADMIN_CODE_noMatch').remove();
				}, 2000);
				$(this).val('');
				$('#INSTITUTE').val('');
				$('#ORG_INITS').val('');
				$('#pv_branch').val('');
				$('#pv_originalBranch').val('');
				getbranchInfo();

				return false;
			}

		},
		select: function (event, ui) {

			var institute = ui.item.customer;
			var orgInits = ui.item.orgInits;
			var adminCode = ui.item.adminCode;
			var branch = ui.item.branch;
			$('#INSTITUTE').val(institute);
			$('#ORG_INITS').val(orgInits);

			$("#ADMIN_CODE").focus();
			setTimeout(function() {
				$('#ADMIN_CODE').val(adminCode);
			}, 500);
			$('#pv_branch').val(branch);
			$('#pv_originalBranch').val(branch);
			getbranchInfo();

		},

		open: function() {
			 $('.ui-autocomplete').css('z-index', 5000);
		},
		close: function() {
			 $('.ui-autocomplete').css('z-index', 1);
		}

	})

	.autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
		return $('<li>')
			.append('<a title="' + item.adminCode + ', ' + item.adminTitle + '">' + item.adminCode + ', ' + item.adminTitle +  '</a>')
			.appendTo(ul);
	};

}

var setACAutoComplete = function () {

	$('#HR_LLN_INPUT').autocomplete({
		source: function (request, response) {
			$.ajax({
				url: base_url + 'SearchLiaison.do?searchLiaison=' + $('#HR_LLN_INPUT').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {


						return {
							//ac_id: $( 'AC_ID', this ).text(),
							last_name: $( 'LNAME', this ).text(),
							first_name: $( 'FNAME', this ).text(),
							email: $( 'EMAIL', this ).text()
						};
					}).get();
					response(data);
				}
			})
		},
		minLength: 2,
		change: function (e, u) {
			//If the No match found" u.item will return null, clear the TextBox.
			if (u.item == null) {
				//Clear the AutoComplete TextBox.
				var pos = $(this).position();
				$('#HR_LLN_INPUT_noMatch').remove();
				$(this).after("<span id='HR_LLN_INPUT_noMatch' class='acNoMatch'>Invalid Selection:<br />Item must be selected from the available options.</span>");
				$('#HR_LLN_INPUT_noMatch').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
				setTimeout(function() {
					$('#HR_LLN_INPUT_noMatch').remove();
				}, 2000);
				$(this).val('');
				return false;
			}
		},
		select: function (event, ui) {
			var li_last_name = "<li id=\"" + ui.item.last_name + "\" ><b>";
			li_last_name += removefunc.getAutoCompRemoveIconElement(ui.item.last_name, ui.item.last_name, '51');
            li_last_name += ui.item.last_name + '</b></li>';

            var li_first_name = "<li id=\"" + ui.item.first_name + "\" ><b>";
			li_first_name += removefunc.getAutoCompRemoveIconElement(ui.item.first_name, ui.item.first_name, '52');
            li_first_name += ui.item.first_name + '</b></li>';

            var li_email = "<li id=\"" + ui.item.email + "\" ><b>";
			li_email += removefunc.getAutoCompRemoveIconElement(ui.item.email, ui.item.email, '53');
			li_email += ui.item.email + '</b></li>';

			$('#HR_LLN_DISP').append(li_last_name).removeClass('hidden');
            $('#HR_LLN_DISP_F').append(li_first_name).removeClass('hidden');
            $('#HR_LLN_DISP_E').append(li_email).removeClass('hidden');
			$('#HR_LLN_INPUT_container').addClass('hidden');
			$('#HR_LLN_INPUT').attr('_required', 'false');
            $('#HR_LLN_section_8').removeClass('hidden');
            $('#h_lastname').val(ui.item.last_name);
            $('#h_firstname').val(ui.item.first_name);
            $('#h_email').val(ui.item.email);

		},
		open: function() {
			 $('.ui-autocomplete').css('z-index', 5000);
		},
		close: function() {
			 $('.ui-autocomplete').css('z-index', 1);
		}
	})
	.autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
		return $('<li>')
			.append('<a title="' + item.last_name + ', ' + item.first_name + '">' + item.last_name + ', ' + item.first_name +  '</a>')
			.appendTo(ul);
	};

}

function addComma(fieldval){
    fieldval = fieldval.replace(/\./g,'');
	var chstr = fieldval.split('');
    var ctext = '';

    for ( var i in chstr ) {
     ctext += chstr[i] + '.';
    }

    return ctext;
}


var removefunc = {
    autoCompletionBaseURL: '/bizflowwebmaker/whrsc_AUT/',

    getAutoCompRemoveIconElement: function (target, targetDescription, tabIndex) {
        var elementString = '<img src="' + removefunc.autoCompletionBaseURL + 'custom/images/delete-icon.png' +
                    '" id="delete-' + target + '" deleteId="' + target +
                    '" title="Remove ' + targetDescription + '" tabindex="' + tabIndex + '" /> ';
        return elementString;
    }
};
