var candidateInfo = function(){
	hyf.util.disableComponent('Candidate_info');
	$('#EMPLID').css('background-color', '#efefef');
	$('#HHSID').css('background-color', '#efefef');
	$('#LAST_NAME').css('background-color', '#efefef');
	$('#FIRST_NAME').css('background-color', '#efefef');
	$('#MIDDLE_INITIAL').css('background-color', '#efefef');
	$('#PAY_PLAN').css('background-color', '#efefef');
	$('#ADMIN_CODE').css('background-color', '#efefef');
	$('#OCC_SERIES').css('background-color', '#efefef');
	$('#GRADE').css('background-color', '#efefef');
	$('#OPDIV').css('background-color', '#efefef');
	$('#STAFF_DIV').css('background-color', '#efefef');
	$('#ORG_TITILE').css('background-color', '#efefef');
	$('#ADDRESS_LINE1').css('background-color', '#efefef');
	$('#ADDRESS_LINE2').css('background-color', '#efefef');
	$('#ADDRESS_CITY').css('background-color', '#efefef');
	$('#ADDRESS_STATE').css('background-color', '#efefef');
	$('#ADDRESS_ZIP').css('background-color', '#efefef');
	$('#PHONE_NUMBER').css('background-color', '#efefef');
	$('#EMAIL_ADDRESS').css('background-color', '#efefef');
	$('#HHS_EMPLMT_STATUS_CODE').css('background-color', '#efefef');
	$('#SEPARATION_DATE').css('background-color', '#efefef');
	$('#PERFORMANCE_RATING_CODE').css('background-color', '#efefef');
	$('#PERFORMANCE_PD_START').css('background-color', '#efefef');
	$('#PERFORMANCE_PD_END').css('background-color', '#efefef');
	$('#COMMENTS').css('background-color', '#efefef');
	$('#POSITION_OCCUPIED').css('background-color', '#efefef');
	$('#TENURE_CODE').css('background-color', '#efefef');
	$('#EMPL_DUTY_STATION').css('background-color', '#efefef');
	$('#LOCATION').css('background-color', '#efefef');
	$('#VETERAN_STATUS_CODE').css('background-color', '#efefef');

	var attCount = $('#attCount').val();
	for (var i=1;i <= attCount;i++) {
		 runActionStatus(i);
	}
};

function  runActionStatus(index) {
	
	$('#BasicTable' + index + 'DOCUMENT_NAME').on('click',function() {
		var procid = $('#BasicTable' + index + 'PROCID').val();
		var attchid = $('#BasicTable' + index + 'ATTACHSEQ').val();
		var fileName = $('#BasicTable' + index + 'DOCUMENT_NAME').text();
		
		var url = "/bizflow/instance/pigetattachfile.jsp?PKIVALUE=N&PROCESSID="+procid+"&IID="+attchid+"&FILENAME="+fileName;
		$("body").append("<iframe TITLE='hiddenFrame' name='hiddenFrame'  src='" + url + "'  style='display:none;'></iframe");

	});
}