/* global BFLog $ X2JS */
/* eslint no-unused-vars:0 */

/*
    Lookup Manager object
    This object will manage lookup values in client side.

    Example of LookupItem Object
    {
        ACTIVE: "1",
        DISPORDER: "",
        ID: "500",
        LABEL: "Existing Position Description (PD)",
        LTYPE: "MDDocumentType",
        PARENTID: "477",
        children: null
    }
*/
var LookupManager = new function () {
    var jsonObject = null;
    /*
        Initialize lookup manager object. This function should be called before using LookupManager.
        This function will retrieve XML String from h_lookupXMLString element and coverts to JSON object.
    */
    var initWithXML = function (lookupXML) {
        var x2js = new X2JS();
        jsonObject = x2js.xml_str2json(lookupXML);
        _generateHierarchy();
    };

    var init = function () {
        if (jsonObject == null) {
            var x2js = new X2JS();
            var lookupXML = $('#h_lookupXMLString').val();
            if (lookupXML == null || lookupXML.length === 0) {
            } else {
                $('#h_lookupXMLString').val('');
            }
            jsonObject = x2js.xml_str2json(lookupXML);
           // _generateHierarchy();
        } else {
        }
    };

    var _findByID = function (items, ID) {
        if (items != null) {
            for (var index = 0; index < items.length; index++) {
                if (items[index].ID === ID) {
                    return items[index];
                }

                if (items[index].children != null && items[index].children.length > 0) {
                    var foundItem = _findByID(items[index].children, ID);
                    if (foundItem != null) {
                        return foundItem;
                    }
                }
            }
            return null;
        }
    };
    var _generateHierarchy = function () {
        try {
            var items = jsonObject.lookup.record;
            if (items != null) {
                var index = 0;
                for (; index < items.length; index++) {
                    if (items[index].PARENTID !== '0') {
                        var parentItem = _findByID(items, items[index].PARENTID);
                        if (parentItem != null) {
                            if (parentItem.children == null) {
                                parentItem.children = [];
                            }
                            parentItem.children.push(JSON.parse(JSON.stringify(items[index])));
                            items[index].movedToParent = true;
                        } else {
                        }
                    }
                }

                for (index = items.length - 1; index >= 0; index--) {
                    if (items[index].movedToParent === true) {
                        items.splice(index, 1);
                    }
                }
            }
        } catch (e) {
        }
    };
    /*
        Find lookup value with ID
        @param {string} ID
        @return {lookupItem}
    */
    var findByID = function (ID) {
        if (jsonObject == null) {
            return null;
        }
        return _findByID(jsonObject.lookup.record, ID);
    };
    var _findByLType = function (items, pathArray) {
        if (items === null || items.length === null || pathArray === null || pathArray.length === 0) {
            return null;
        }

        var targetPath = null;
        var targetLabel = null;
        var startIndex = pathArray[0].indexOf('[');
        if (startIndex === -1) {
            targetPath = pathArray[0];
            targetLabel = null;
        } else {
            targetPath = pathArray[0].substring(0, startIndex);
            targetLabel = pathArray[0].substring(startIndex + 1, pathArray[0].length - 1);
        }

        var foundItems = [];
        for (var index = 0; index < items.length; index++) {
            if (items[index].LTYPE === targetPath) {
                if (targetLabel != null) {
                    if (items[index].LABEL !== targetLabel) {
                        continue;
                    }
                }
                if (pathArray.length === 1) {
                    foundItems.push(items[index]);
                } else {
                    var pathArrayClone = pathArray.slice();
                    pathArrayClone.splice(0, 1);
                    var foundItemsFromSub = _findByLType(items[index].children, pathArrayClone);
                    if (foundItemsFromSub != null && foundItemsFromSub.length > 0) {
                        foundItems.push.apply(foundItems, foundItemsFromSub);
                    }
                }
            }
        }

        return foundItems;
    };

    /*
        Find lookup values with the path of LType
        @param {string} LTYPEPath - Path of LType. Ex) 'RequestType[Appointment]/ClassificationType' or 'RequestType'
        @return {Array}
    */
    // If LTYPEPath contains '/' as a value, not LTYPE Seperator, then '/' should be decorated as '*/*'
    // '*/*' will be translated to '/' after separating paths.

    var findByLTYPE = function (LTYPEPath) {
        if (jsonObject == null) {
            return null;
        }
        var translatedLTYPEPath = LTYPEPath.split('*/*').join('*_*');
        var paths = translatedLTYPEPath.split('/');
        var translatedPaths = [];
        for (var index = 0; index < paths.length; index++) {
            var newPath = paths[index].split('*_*').join('/');
            translatedPaths.push(newPath);
        }

        var result = _findByLType(jsonObject.lookup.record, translatedPaths);
        return result;
    };

    var checkForm = function() {
        if ($('#h_lookupXMLString').length !== 0) {
        }
    };
    checkForm();

    return {
        init: init,
        initWithXML: initWithXML,
        findByLTYPE: findByLTYPE,
        findByID: findByID
    }
}();

// function TestLookupManager() {
//     var testResult = LookupManager.findByLTYPE('RequestType');
//     console.log(testResult);
//
//     var testResult = LookupManager.findByLTYPE('RequestType/ClassificationType');
//     console.log(testResult);
//
//     testResult = LookupManager.findByLTYPE('RequestType[Appointment]/ClassificationType');
//     console.log(testResult);
//
//     testResult = LookupManager.findByLTYPE('RequestType[Appointment]/ClassificationType[Update Major Duties]/MandatoryDocument');
//     console.log(testResult);
// }
