/* eslint yoda:0, operator-linebreak:0 */

var utility = {
    autoCompletionBaseURL: '/bizflowwebmaker/recruitment_AUT/',
    showDebugLog: true,
    showErrorLog: true,
    showInfoLog: true,
    debugLog: function (message) {
        if (utility.showDebugLog === true) {
            if (console && console.log) {
                console.log('DEBUG: ' + message);
            }
        }
    },
    errorLog: function (message) {
        if (utility.showErrorLog === true) {
            if (console && console.log) {
                console.log('ERROR: ' + message);
            }
        }
    },
    infoLog: function (message) {
        if (utility.showInfoLog === true) {
            if (console && console.log) {
                console.log('INFO: ' + message);
            }
        }
    },

    getAnchorID: function (tabID) {
        return 'tab_control_tab_' + tabID;
    },
    getTabIDFromAnchor: function (node) {
        if (node != null && node.id != null) {
            var lastIndex = node.id.lastIndexOf('_');
            if (lastIndex >= 0) {
                return node.id.substring(lastIndex + 1);
            }
        }
        return null;
    },
    getTabIDFromAnchorID: function (node) {
        if (node != null && node.length > 0) {
            var lastIndex = node.lastIndexOf('_');
            if (lastIndex >= 0) {
                return node.substring(lastIndex + 1);
            }
        }
        return null;
    },
    // dateFormat can include yyyy mm dd hh MM ss pattern and these pattern will be replaced by real values.
    // yyyy - 4 digit year, mm - month, dd - day, hh - hours, MM - minutes, ss - seconds
    formatDateString: function (dateFormat, yyyy, mm, dd, hh, MM, ss) {
        if (dateFormat == null || dateFormat.length === 0) {
            dateFormat = 'mm/dd/yyyy';
        }
        var dateString = dateFormat;
        if (yyyy != null && yyyy.length > 0) {
            dateString = dateString.replace(/yyyy/, yyyy);
        }
        if (mm != null && mm.length > 0) {
            dateString = dateString.replace(/mm/, mm);
        }
        if (dd != null && dd.length > 0) {
            dateString = dateString.replace(/dd/, dd);
        }
        if (hh != null && hh.length > 0) {
            var amPM = 'AM';
            dateString = dateString.replace(/HH/, hh);
            var hh12 = hh;
            if (hh12 >= 12) {
                amPM = 'PM';
                hh12 = (hh12 > 12) ? (hh12 - 12) : hh12;
                hh12 = '' + hh12;
                hh12 = (hh12.length === 1) ? ('0' + hh12) : hh12;
            }
            dateString = dateString.replace(/hh/, hh12);
            dateString = dateString.replace(/a/, amPM);
        }
        if (MM != null && MM.length > 0) {
            dateString = dateString.replace(/MM/, MM);
        }
        if (ss != null && ss.length > 0) {
            dateString = dateString.replace(/ss/, ss);
        }
        dateString = dateString.replace(/yyyy/, '');
        dateString = dateString.replace(/mm/, '');
        dateString = dateString.replace(/dd/, '');
        dateString = dateString.replace(/hh/, '');
        dateString = dateString.replace(/MM/, '');
        dateString = dateString.replace(/ss/, '');
        return dateString;
    },
    //
    // option : {
    //     isUTC: true // true or false
    //     dateFormat: "yyyy/mm/dd"    // The patterns yyyy mm dd hh MM ss will be replaced with real values.
    // }
    //
    getDateString: function (option, when) {
        var year, month, day, hours, minutes, seconds;
        if (option.isUTC === true) {
            year = when.getUTCFullYear();
            month = when.getUTCMonth() + 1;
            day = when.getUTCDate();
            hours = when.getUTCHours();
            minutes = when.getUTCMinutes();
            seconds = when.getUTCSeconds();
        } else {
            year = when.getFullYear();
            month = when.getMonth() + 1;
            day = when.getDate();
            hours = when.getHours();
            minutes = when.getMinutes();
            seconds = when.getSeconds();
        }
        if (month < 10) {
            month = '0' + month;
        }
        if (day < 10) {
            day = '0' + day;
        }
        if (hours < 10) {
            hours = '0' + hours;
        }
        if (minutes < 10) {
            minutes = '0' + minutes;
        }
        if (seconds < 10) {
            seconds = '0' + seconds;
        }
        year = '' + year;
        month = '' + month;
        day = '' + day;
        hours = '' + hours;
        minutes = '' + minutes;
        seconds = '' + seconds;
        return utility.formatDateString(option.dateFormat, year, month, day, hours, minutes, seconds);
    },
    getNowUTCString: function () {
        var now = new Date();
        return utility.getDateString({isUTC: true, dateFormat: 'yyyy/mm/dd hh:MM:ss'}, now);
    },
    // The parameter "components" is array of component IDs.
    enableComponents: function (components) {
        if (components != null && components.length > 0) {
            components.forEach(function (component) {
                hyf.util.enableComponent(component);
            });
        }
    },
    // The parameter "components" is array of component IDs.
    disableComponents: function (components) {
        if (components != null && components.length > 0) {
            components.forEach(function (component) {
                hyf.util.disableComponent(component);
            });
        }
    },
    existInArray: function (array, targetItem) {
        var found = false;
        if (array) {
            var foundItems = array.filter(function (item) {
                return item === targetItem;
            });
            if (foundItems && foundItems.length > 0) {
                found = true;
            }
        }
        return found;
    },
    /**
     * Event handler code generated by WebMaker when exit WIH action is used in Event tab of the WM Studio.
     * Moved the implementation here so as to have better development control over the event handler.
     * @param btnId - element id of the exit button
     */
    exitWitemHandler: function (btnId) {
        var evt = (window.event) ? window.event : e;
        var sourceComponent = null;
        if ((evt != null) && (typeof (evt) !== 'undefined')) {
            sourceComponent = (evt.target) ? evt.target : evt.srcElement;
            if ((sourceComponent != null) && (sourceComponent.nodeType === 3)) { // defeat Safari bug
                sourceComponent = sourceComponent.parentNode;
            }
        }
        var objEventSource = {
            name: 'EventSource',
            option: 'field',
            event: evt,
            component: sourceComponent,
            value: btnId,
            field: document.getElementById(btnId)
        };
        return dojo.hitch(objEventSource.field, function () {
            var objWIHAction = {name: 'WIHAction', option: 'WIHAction', value: 'exit'};
            var objResponse = {name: 'Response', option: 'Default', value: ''};
            hyf.HSGAction.handleWIHAction(objWIHAction, objResponse, objEventSource);
        })();
    },
    initMaxSizePerTab: function (tabID) {
        var inputControls = $('#' + tabID + ' input[size]');
        $.each(inputControls, function (index, control) {
            var maxSize = $(control).attr('size');
            var id = $(control).attr('id');
            var controlType = $(control).attr('_type');
            var alwaysReadonly = $('control').attr('alwaysReadonly');
            var alwaysDisabled = $('control').attr('alwaysDisabled');

            // Skip if the control is date control
            if (controlType !== 'date' && typeof id !== 'undefined' && !alwaysReadonly && !alwaysDisabled) {
                if ($(control).parent().length === 1
                    && $(control).parent().parent().length === 1
                    && $(control).parent().parent().parent().length === 1) {
                    var initialMessage = $(control).val();
                    var target;
                    if ($(control).hasClass('dijitInputInner')) {
                        target = $(control).parent().parent().parent();
                    } else {
                        target = $(control).parent().parent();
                    }
                    if (target.find('p.sizeLabel').length === 0) {
                        target.append('<p id="' + (id + '_sizeLabel') + '" class="sizeLabel" debugMessage="' + initialMessage + '">(Now: ' + initialMessage.length + ' / Max: ' + maxSize + ')</p>');
                        $('#' + id + '_sizeLabel').hide();
                        $(control).on('focus', function () {
                            var disabled = $(this).attr('disabled');
                            var readonly = $(this).prop('readonly');
                            if (!disabled && !readonly) {
                                $('#' + id + '_sizeLabel').show();
                            }
                        });
                        $(control).on('blur', function () {
                            $('#' + id + '_sizeLabel').hide();
                        });
                        $(control).on('keyup paste blur change', function () {
                            var message = $(control).val();
                            if (message.length > maxSize) {
                                $(control).val(message.substring(0, maxSize));
                            }
                            $('#' + id + '_sizeLabel').text('(Now: ' + message.length + ' / Max: ' + maxSize + ')');
                        })
                    }
                }
            }
        });

        inputControls = $('#' + tabID + ' textarea.textbox[maxlength]');
        $.each(inputControls, function (index, control) {
            var maxSize = $(control).attr('maxlength');
            var id = $(control).attr('id');
            var alwaysReadonly = $('control').attr('alwaysReadonly');
            var alwaysDisabled = $('control').attr('alwaysDisabled');
            if ($(control).parent().length === 1 && typeof id !== 'undefined' && !alwaysReadonly && !alwaysDisabled) {
                var initialMessage = $(control).val();
                if ($(control).parent().find('p.sizeLabel').length === 0) {
                    $(control).parent().append('<p id="' + (id + '_sizeLabel') + '" class="sizeLabel">(Now: ' + initialMessage.length + ' / Max: ' + maxSize + ')</p>');
                    $('#' + id + '_sizeLabel').hide();
                    $(control).on('focus', function () {
                        var disabled = $(this).attr('disabled');
                        var readonly = $(this).prop('readonly');
                        if (!disabled && !readonly) {
                            $('#' + id + '_sizeLabel').show();
                        }
                    });
                    $(control).on('blur', function () {
                        $('#' + id + '_sizeLabel').hide();
                    });
                    $(control).on('keyup keypress blur change', function () {
                        var message = $(control).val();
                        $('#' + id + '_sizeLabel').text('(Now: ' + message.length + ' / Max: ' + maxSize + ')');
                    })
                }
            }
        });
    },
    setDateIconTabOrder: function () {
        var dateTextBoxes = $('input.textbox[_type=date]');
        $.each(dateTextBoxes, function (index, control) {
            var tabIndex = $(control).attr('tabindex');
            if ($.isNumeric(tabIndex) === true && tabIndex > 0) {
                var controlID = $(control).attr('id');
                var newTabIndex = tabIndex * 1 + 1;
                $('#' + controlID + '_calendar_anchor').attr('tabindex', newTabIndex);
            }
        });
    },
    callPartialPage: function (o, action, sourceGroup, targetGroup) {
        if (window.location.pathname.indexOf('bizflowwebmaker') > -1 && action.indexOf('/') === 0) {
            action = '/bizflowwebmaker' + action;
        }
        var objEventSource5 = {
            name: 'EventSource',
            optio: 'field',
            even: null,
            componen: null,
            value: targetGroup,
            field: dojo.byId(targetGroup)
        };
        var objAction = {
            name: 'Action',
            option: 'Action',
            value: action
        };
        var objSourceGroup = null;
        if (null === sourceGroup || '' === sourceGroup || 'all' === sourceGroup || 'ALL' === sourceGroup) {
            objSourceGroup = {name: 'SourceGroup', option: 'AllFormData', value: ''};
        } else {
            objSourceGroup = {name: 'SourceGroup', option: 'PageGroup', value: sourceGroup};
        }
        var objTargetGroup = {
            name: 'TargetGroup',
            option: 'PageGroup',
            value: targetGroup
        };
        var objValidate = {
            name: 'Validate',
            option: 'Static',
            value: 'false'
        };
        hyf.FMAction.handleAjaxSubmission(objAction, objSourceGroup, objTargetGroup, objValidate, objEventSource5);
    },
    submitFormPage: function (o, action) {
        var e = (typeof (event) !== 'undefined') ? event : arguments[0];
        var evt = (window.event) ? window.event : e;
        var sourceComponent = null;
        if ((evt != null) && (typeof (evt) !== 'undefined')) {
            sourceComponent = (evt.target) ? evt.target : evt.srcElement;
            if ((sourceComponent != null) && (sourceComponent.nodeType === 3)) { // defeat Safari bug
                sourceComponent = sourceComponent.parentNode;
            }
        }
        var objId = null;
        if (o !== 'undefined' && o != null && o.id !== 'undefined' && o.id != null) {
            objId = o.id;
        }
        var objEventSource = {
            name: 'EventSource',
            option: 'field',
            event: evt,
            component: sourceComponent,
            value: objId,
            field: document.getElementById(objId)
        };
        return dojo.hitch(objEventSource.field, function () {
            var objAction = {
                name: 'Action',
                option: 'Action',
                value: action
            };
            var objValidate = {
                name: 'Validate',
                option: 'Static',
                value: 'false'
            };
            hyf.FMAction.handleFormSubmission(objAction, objValidate, objEventSource);
        })();
    },
    enableAllFields: function () {
        utility.setAllFieldsEnabledDisabled('enable');
    },
    disableAllFields: function () {
        utility.setAllFieldsEnabledDisabled('disable');
    },
    setAllFieldsEnabledDisabled: function (mode) {
        // mode: disable, enable
        if ('disable' === mode) {
            $('input').attr('disabled', 'disabled');
            $('select').attr('disabled', 'disabled');
            $('textarea').attr('disabled', 'disabled');
        } else {
            $('input').removeAttr('disabled');
            $('select').removeAttr('disabled');
            $('textarea').removeAttr('disabled');
        }
    },
    // Grey out screen and prevent from user input
    greyOutScreen: function (mode, messageBody) {
        try {
            if (mode) {
                if (null == messageBody || '' === messageBody) {
                    messageBody = "<p style='font-size:30px;color:white;'>Please wait...</p>";
                }
                utility.blockScreen(messageBody);
            } else {
                utility.unblockScreen();
            }
        } catch (e) {}
    },

    blockScreen: function (messageContent) {
        if (null == messageContent || '' === messageContent) {
            messageContent = 'Please wait...';
        }
        $.blockUI({
            message: messageContent,
            css: {
                border: 'none',
                padding: '20px',
                backgroundColor: '#000',
                '-webkit-border-radius': '15px',
                '-moz-border-radius': '15px',
                opacity: 0.5,
                color: '#000'
        } });
    },
    unblockScreen: function (waitTime) {
        if (null == waitTime) {
            waitTime = 500;
        }
        $.unblockUI({ fadeOut: waitTime });
    },
    getAutoCompRemoveIconElement: function (target, targetDescription, tabIndex) {
        var elementString = '<img src="' + utility.autoCompletionBaseURL + 'custom/images/delete-icon.png' +
                    '" id="delete-' + target + '" deleteId="' + target +
                    '" title="Remove ' + targetDescription + '" tabindex="' + tabIndex + '" /> ';
        return elementString;
    },
	getFirstLastName: function (fullName) {
		var fullName = fullName.split(",").reverse().join(" ").trim();
		if(fullName.split(" ").length > 2) {
			fullName = fullName.split(" ");
			fullName.splice(1, 1);
			fullName = fullName.join(" ");     
		} 
		return fullName;
    },
	_readOnly: null,
    isReadOnly: function () {
        if (this._readOnly == null) {
            this._readOnly = $('#h_readOnly').val();
            if (this._readOnly === 'y') {
                this._readOnly = true;
            } else {
                this._readOnly = false;
            }
        }
		else {
			 this._readOnly = $('#h_readOnly').val();	
			  if (this._readOnly === 'y') {
                this._readOnly = true;
            } else {
                this._readOnly = false;
            }
		}
        return this._readOnly;
    },
    multiSelectFD: function (mfieldnm, mCheck){
	
        $("input[type=checkbox][name=" + mfieldnm + "_M]").filter(function(){ return $(this).prop("checked"); }).parent().parent().show();
        $("input[type=checkbox][name=" + mfieldnm + "_M]").filter(function(){ return !$(this).prop("checked"); }).parent().parent().hide();

        // add event handler to the selectbox - whenever selection is made, it should be synced up in the "Selected Item" data element
        $("#" + mfieldnm).on("change", function(){
            var selVal = $(this).children("option:selected").val();
            //alert (selVal);
            //
            var selectedcnt = utility.chkMselectValuee(mfieldnm);
            if((mfieldnm == 'AP_APPROVER1' || mfieldnm == 'AP_APPROVER2' || mfieldnm == 'AP_APPROVER3' || mfieldnm == 'AP_APPROVER4' || mfieldnm == 'AP_APPROVER5' || mfieldnm == 'AP_APPROVER6' || mfieldnm == 'AP_APPROVER7' || mfieldnm == 'AP_APPROVER8' || mfieldnm == 'AP_APPROVER9' || mfieldnm == 'AP_APPROVER10') && selectedcnt == 10 ){
                
                alert ("Please select Approvers up to 10.");
            }else{
            
                if (selVal != '') {
                    //selVal = encodeURl(selVal);
                    // capture the selected item and set the multiselect checkbox area
                    var selChkElms = $('input[type=checkbox][name=' + mfieldnm + '_M][value=\"' + selVal + '\"]');

                    if (selChkElms.length > 0) {  // the length should really be 1 if correctly identified
                        selChkElms.prop("checked", true);
                        $("label[for=" + selChkElms[0].id + "]").parent().removeClass("selected");
                        $("label[for=" + selChkElms[0].id + "]").parent().addClass("selected");
                        selChkElms.parent().parent().show();  // show parent/parent <tr><td><input ...
                    }
                    $("input[type=checkbox][name=" + mfieldnm + "_M]").trigger("change");
                }
            }
            // after select propagation is done to selected item checkbox list, clear current select from dropdown
            $(this).val("");
        });

        // add event handler to the selected item element - whenever checkbox is unched, it should be hidden from the "Selected Item" display
        $("input[type=checkbox][name=" + mfieldnm + "_M]").on("change", function(){
            if (!$(this).prop("checked")) {
                $(this).parent().parent().hide();  // hide parent/parent <tr><td><input ...
            }

            // if no selected items left, set attribute for error check.  Otherwise, unset attribute to avoid error.
            // Madetory field check default = 0 
            if (mCheck > 0){
                if ($("input[type=checkbox][name=" + mfieldnm + "_M]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
                    $("#" + mfieldnm).attr("_required", "true");
                } else {
                    $("#" + mfieldnm).attr("_required", "false");
                }
            }
        });
    },
    
    chkMselectValuee: function (mselectName){
    
        var ct_deter =  $("#" + mselectName + " option").size();

        var chkmulti = 0;

        for (var ij = 1 ; ij <= ct_deter - 1; ij++){

            if($("#" + mselectName + "_M" + ij).prop('checked') == true){
                chkmulti = chkmulti + 1;
            }

        }

            return chkmulti; 

    }
    
};
